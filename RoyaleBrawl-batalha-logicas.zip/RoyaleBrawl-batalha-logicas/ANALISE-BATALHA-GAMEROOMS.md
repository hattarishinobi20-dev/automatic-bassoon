# ANÁLISE PROFUNDA 1:1 — SERVIDOR RoyaleBrawl-v1
## Batalhas Online + GameRooms + Todas as Dependências Diretas e Indiretas

**Repositório:** `https://github.com/Super-brawl-team/RoyaleBrawl-v1.git` (clone em `/home/user/repo`, commit `a889232 "hoo lee sheet"`)
**Cliente alvo:** Brawl Stars IPA **v1.1714** (`GameVersion.MAJOR = 1`, `GameVersion.BUILD = 1714`)
**Stack:** C# / **.NET 6.0** (`net6.0`), MySQL (tabelas `accounts`, `alliances`), Newtonsoft.Json, MySql.Data, Colorful.Console
**Portas:** TCP **9339** (hardcoded em `Resources.InitNetwork()`), UDP **9449** (`config.json → udp_port`)

---

## A — ESTRUTURA DO SERVIDOR

O servidor são **3 projetos** na solution `src/RoyaleBrawl Server Emulator.sln`:

```
src/
├── Supercell.Laser.Titan/            → Biblioteca base (streams, cripto, math, JSON)
├── Supercell.Laser.Logic/            → Lógica do jogo (batalha, dados, mensagens, home, time)
│   ├── Assets/csv_logic/*.csv        → characters.csv, skills.csv, projectiles.csv, area_effects.csv,
│   │                                   items.csv, tiles.csv, locations.csv, cards.csv, ...
│   ├── Assets/tilemaps.json          → mapas em ASCII (grid de códigos de tile)
│   ├── Avatar/                       → ClientAvatar (BattleId, UdpSessionId, TeamIndex, OwnIndex)
│   ├── Battle/                       → ★ NÚCLEO DA BATALHA (ver seção B/C)
│   ├── Club/, Friends/, Stream/      → social (indireto)
│   ├── Command/                      → CommandManager + comandos home (500/506/507/1000)
│   ├── Data/                         → DataTables, DataType, Row/Table (leitor CSV), *Data.cs
│   ├── Home/                         → ClientHome, HomeMode, Hero, EventData, Milestones
│   ├── Listener/                     → LogicGameListener (abstrato), LogicServerListener (interface)
│   ├── Message/                      → TODAS as mensagens (Account, Battle, Club, Friends, Home, Ranking, Team, Udp)
│   ├── Team/                         → TeamEntry, TeamMember, stream de time
│   ├── Time/GameTime.cs              → contador de tick da batalha
│   └── Util/                         → GameModeUtil, GamePlayUtil (regras de modo de jogo)
├── Supercell.Laser.Server/           → Executável (Program.cs)
│   ├── Database/                     → Accounts, Alliances, Cache (AccountCache 30s, AllianceCache), Models/Account
│   ├── Handler/                      → CmdHandler (console /ban /maintenance...), ExitHandler
│   ├── Logic/Game/                   → ★ Battles.cs, Matchmaking.cs, Teams.cs, Events.cs, Leaderboards.cs
│   ├── Logic/                        → HomeGameListener (TCP), ServerListener (LogicServerListener)
│   ├── Message/                      → ★ MessageManager.cs (handlers), Processor.cs (filas send/recv)
│   ├── Networking/                   → TCPGateway, Connections, Connection, Messaging (RC4)
│   │   ├── Session/                  → Session, Sessions
│   │   └── UDP/                      → UDPGateway, UDPSocket, UDP/Game/UDPGameListener
│   ├── Settings/                     → Configuration (config.json), Fingerprint
│   ├── config.json                   → udp_host, udp_port, database_*
│   ├── gameplay.json                 → slots de evento → modos permitidos
│   └── Resources.cs                  → boot: InitDatabase/InitLogic/InitNetwork
├── Settings.json                     → RC4Key etc. (a chave real é HARDCODED, ver seção E)
├── database.sql                      → schema MySQL
└── scripti.js                        → script Frida (debug do client, NÃO faz parte do servidor)
```

### Boot (`Program.Main` → `Resources.*`)
```
Program.Main()
 ├─ Configuration.LoadFromFile("config.json")
 ├─ Resources.InitDatabase()   → Accounts.Init / Alliances.Init (MySQL + caches)
 ├─ Resources.InitLogic()      → Fingerprint.Load, DataTables.Load, Events.Init, Sessions.Init,
 │                              Leaderboards.Init, Battles.Init, Matchmaking.Init, Teams.Init
 └─ Resources.InitNetwork()    → Processor.Init, Connections.Init,
                                 LogicServerListener.Instance = new ServerListener(),
                                 UDPGateway.Init("0.0.0.0", udp_port), TCPGateway.Init("0.0.0.0", 9339)
```

---

## B — GAMEROOMS

### B.1 Não existe uma classe chamada `GameRoom` nem `Room`
A "GameRoom" deste servidor **É a classe `BattleMode`** (`Supercell.Laser.Logic/Battle/BattleMode.cs`, 1006 linhas). Não há maquinário de lobby: a sala nasce já com todos os jogadores definidos e a partida inicia imediatamente. **Estados como `WAITING`/`READY` de sala: NÃO ENCONTRADO** (o "lobby" existe apenas fora da batalha, no `TeamEntry` pré-partida).

### B.2 Implementações relacionadas a sala

| Papel | Arquivo | Classe | Tipo |
|---|---|---|---|
| **GameRoom em si** (estado da partida, tick, players, times, mapa) | `Logic/Battle/BattleMode.cs` | `BattleMode` | instância por partida |
| **Registro/gerenciador de salas** (dicionário id→BattleMode, GC) | `Server/Logic/Game/Battles.cs` | `Battles` (static) | singleton |
| **Fábrica de salas** (cria BattleMode + preenche jogadores) | `Server/Logic/Game/Matchmaking.cs` | `MatchmakingSlot.StartGame()` | método |
| **Fila de busca por evento** | `Server/Logic/Game/Matchmaking.cs` | `Matchmaking` + `MatchmakingSlot` + `MatchmakingEntry` | static + instâncias |
| **Lobby pré-partida (times prontos)** | `Logic/Team/TeamEntry.cs` + `Server/Logic/Game/Teams.cs` | `TeamEntry`, `TeamMember`, `Teams` | lobby, não a sala de jogo |

### B.3 `BattleMode` — ficha completa

**Construtor** `BattleMode(int locationId)`:
```csharp
m_winnerTeam = -1;
m_locationId = locationId;
m_gameModeVariation  = GameModeUtil.GetGameModeVariation(Location.GameMode);   // 0..6
m_playersCountWithGameModeVariation = GamePlayUtil.GetPlayerCountWithGameModeVariation(variation); // 6 ou 10
m_inputQueue = new Queue<ClientInput>();
m_randomSeed = 0;  m_random = new LogicRandom(0);      // RNG DETERMINÍSTICO (semente fixa 0)
m_players / m_playersBySessionId / m_playersByObjectGlobalId / m_deadPlayers / m_spectators
m_time = new GameTime();
m_tileMap = TileMapFactory.CreateTileMap(Location.AllowedMaps);   // lê Assets/tilemaps.json
m_playArea = new Rect(0, 0, m_tileMap.LogicWidth, m_tileMap.LogicHeight);
m_gameObjectManager = new GameObjectManager(this);
m_ART_TEST = false;
```

**Estado interno (campos reais):**

| Campo | Tipo | Função |
|---|---|---|
| `m_updateTimer` | `System.Threading.Timer` | loop da partida: `new Timer(Update, null, 0, 1000/20)` → **50 ms/tick = 20 TPS** |
| `m_NORMAL_TICKS = 3600` | const | duração 3 min (modos normais, `GameModeUtil.GetBattleTicks`) |
| `m_SHOWDOWN_TICKS = 16000` | const | duração 800 s ≈ 13m20s (variação 6 / BattleRoyale) |
| `m_locationId` | int | id global da `LocationData` (tabela 15) → define modo + mapa |
| `m_gameModeVariation` | int | 0 CoinRush(GemGrab), 1 Campaign, 2 AttackDefend(Heist), 3 BountyHunter, 4 Artifact, 5 LaserBall(BrawlBall), 6 BattleRoyale(Showdown) |
| `m_players` | `List<BattlePlayer>` | lista de jogadores (humanos + bots) |
| `m_playersBySessionId` | `Dictionary<long, BattlePlayer>` | sessão UDP → player |
| `m_playersByObjectGlobalId` | `Dictionary<int, BattlePlayer>` | Character.GlobalID → player |
| `m_spectators` | `Dictionary<long, LogicGameListener>` | espectadores |
| `m_gameObjectManager` | `GameObjectManager` | todos os objetos da partida |
| `m_tileMap` / `m_playArea` | `TileMap` / `Rect` | mapa e limites |
| `m_time` | `GameTime` | tick atual (`GetTicksGone()`) |
| `m_random` (seed 0) | `LogicRandom` | loot boxes 50%, ângulos de itens, etc. |
| `m_winnerTeam` | int | -1 empate / 0 / 1 |
| `m_deadPlayers` | `Queue<DiedEntry>` | fila de respawn (`{DeathTick, Player}`) |
| `m_playersAlive` | int | contagem p/ BattleRoyale |
| `m_gemGrabCountdown` | int | countdown de vitória (GemGrab/Artifact) — **serializado no VisionUpdate** |
| `m_inputQueue` | `Queue<ClientInput>` | inputs recebidos via UDP |
| `m_ART_TEST`, `m_BATTLE_SIM`, `m_USE_BOT_DEBUG` | bool | flags de debug (**só `m_ART_TEST=false` é setado; nunca ligadas em runtime**) |
| `IsGameOver` | propriedade | lida pelo GC de `Battles` |
| `Id` | propriedade long | id da sala (atribuído por `Battles.Add`) |

**Métodos (todos reais):**
`Start()`, `Update(object)`, `ExecuteOneTick()`, `Tick()`, `AddPlayer(BattlePlayer, long)`, `AddGameObjects()`, `AddClientInput(ClientInput, long)`, `AddSpectator(long, LogicGameListener)`, `RemoveSpectator(long)`, `HandleSpectatorInput(...)`, `HandleClientInput(...)`, `HandleIncomingInputMessages()`, `TickSpawnHeroes()`, `TickSpawnEventStuffDelayed()`, `PlayerDied(BattlePlayer)`, `CalculateIsGameOver()`, `GameOver()`, `SendBattleEndToPlayers()`, `SendVisionUpdateToPlayers()`, `UpdatePlayerStatus()` (**corpo vazio — TODO**), `IsTileOnPoisonArea(int,int)`, `IsInPlayArea(int,int)`, `GetPlayers()`, `GetPlayer(int)`, `GetPlayerBySessionId(long)`, `GetPlayerWithObject(int)`, `GetTeamPlayersCount(int)`, `GetTeamScore(int)`, `GetPlayersAliveCountForBattleRoyale()`, `GetRandomInt(min,max)`, `GetTicksGone()`, `GetGameModeVariation()`, `GetPlayersCountWithGameModeVariation()`, `GetRandomSeed()`, `GetTileMap()`, `GetBattleMode()`, `GetGemGrabCountdown()`, `ChangePlayerSessionId(long,long)`, `Location` (property → `LocationData`).

**Times:** não existem objetos "Team" dentro da batalha. O time de um objeto é derivado do **Index**: `character.SetIndex(player.PlayerIndex + 16 * player.TeamIndex)` → **time = `GetIndex() / 16`**, **índice do jogador no time = `GetIndex() % 16`**.

**ID da sala:** `battle.Id = Battles.Add(battle)` (contador `++m_battleIdCounter`), exposto ao player via `player.Avatar.BattleId = Id` em `AddPlayer` (usado para espectate e re-login).

**Mapa/Modo:** vindos de `LocationData` (CSV `locations.csv`, tabela 15): `GameMode` (string → variação via `GameModeUtil.GetGameModeVariation`) e `AllowedMaps` (nome da chave em `Assets/tilemaps.json`).

### B.4 Quem faz o quê (resposta direta ao enunciado)

| Ação | Responsável real |
|---|---|
| **Cria a GameRoom** | `MatchmakingSlot.StartGame(List<MatchmakingEntry>)` → `new BattleMode(EventData.LocationId)` + `Battles.Add(battle)` |
| **Adiciona jogadores** | `MatchmakingSlot.StartGame()` → `battle.AddPlayer(player, sessionId)` (humanos) e `battle.AddPlayer(bot, -1)` (bots) |
| **Popula objetos/spawns** | `MatchmakingSlot.StartGame()` → `battle.AddGameObjects()` |
| **Notifica cliente do início** | `MatchmakingSlot.StartGame()` → envia `StartLoadingMessage` (20559) por TCP |
| **Inicia o loop** | `MatchmakingSlot.StartGame()` → `battle.Start()` (Timer 20 TPS) |
| **Atualiza a cada tick** | `BattleMode.ExecuteOneTick()` (callback do Timer) → `GameObjectManager.PreTick()/Tick()` + `TileMap.Tick()` + `TickSpawnHeroes()` |
| **Encerra** | `BattleMode.ExecuteOneTick()` → `CalculateIsGameOver()` == true → `m_updateTimer.Dispose()` + `GameOver()` + `IsGameOver = true` (ou catch de exceção idem) |
| **Destrói/libera** | `Battles.Update()` (thread, 1 s) → remove do `ConcurrentDictionary` quando `IsGameOver`; objeto segue para GC |

---

## C — BATALHA ONLINE: TODA A LÓGICA ENCONTRADA

### C.1 O loop de tick (`BattleMode.ExecuteOneTick`, chamado pelo Timer a cada 50 ms)
```
ExecuteOneTick()
 ├─ HandleIncomingInputMessages()          // esvazia m_inputQueue → HandleClientInput por input
 ├─ foreach player: player.KillList.Clear()
 ├─ if CalculateIsGameOver():
 │    ├─ m_updateTimer.Dispose()
 │    ├─ GameOver() → SendBattleEndToPlayers()
 │    └─ IsGameOver = true
 ├─ m_gameObjectManager.PreTick()          // destrói objetos mortos, PreTick dos vivos, flush add/remove
 ├─ Tick()
 │    ├─ m_gameObjectManager.Tick()        // Tick() de TODO GameObject
 │    ├─ TickSpawnEventStuffDelayed()      // GemGrab: gemas no centro a cada 100 ticks; Artifact: 1 gema no tick 600
 │    ├─ m_tileMap.Tick(...)               // VAZIO ("todo or smth")
 │    ├─ TickSpawnHeroes()                 // respawn
 │    └─ UpdatePlayerStatus()              // VAZIO (TODO)
 ├─ m_time.IncreaseTick()
 └─ SendVisionUpdateToPlayers()            // 1 VisionUpdateMessage por player + 1 p/ espectadores
```
Exceção em qualquer ponto → `m_updateTimer.Dispose()`, `IsGameOver = true` (batalha morre silenciosamente, **sem BattleEndMessage** nesse caminho).

### C.2 Entrada de comandos (`ClientInput`)
`ClientInput.Decode(ByteStream)` lê: `Index` (VInt), VInt ignorado ("always 1"), `Type` (VInt), `X` (VInt), `Y` (VInt).
**`AutoAttack`/`AutoAttackTarget` existem como campos mas NÃO são decodificados** (sempre false/0).

`BattleMode.HandleClientInput(input)` (rodado dentro do tick):
| `Type` | Ação |
|---|---|
| **100** | `character.MoveTo(input.X, input.Y)` — movimento (coordenadas absolutas) |
| **107** | `character.UltiEnabled()` (marca "usando ultimate") |
| **108** | `character.UltiDisabled()` |
| **0–99** | `skill = character.GetSkill(input.Type)` (SkillData por id na tabela 20). Se `skill.Name == CharacterData.WeaponSkill` → `UltiDisabled()`; se `== UltimateSkill` → `UltiEnabled()` + `player.UseUlti()` (zera carga). Então `character.ActivateSkill(isUlti, input.X - char.X, input.Y - char.Y)` (**delta**) |
| outros | `Debugger.Warning("Input is unhandled: " + Type)` |
| *cases 2 e 0 (ataque/super "clássicos")* | **COMENTADOS no código** (bloco `/* ... */` em `HandleClientInput`) |
Validação: player precisa existir em `m_playersBySessionId` e `input.Index > player.LastHandledInput` (anti-replay/ordenação; `LastHandledInput` atualizado).

### C.3 Movimento (`Character.MoveTo` + `HandleMoveAndAttack`)
- `MoveTo(x, y)`: velocidade base = `CharacterData.Speed + GetBuffedSpeed() + GetUnbuffedSpeed()` (só para checar != 0); aborta se fora de `IsInPlayArea` ou `IsChargeActive()`; `m_isMoving = true`; se `m_attackingTicks >= 63` → `m_state = 1`; destino = `LogicVector2(x,y)`; ângulo = `LogicMath.GetAngle(delta)` se delta > 150 em algum eixo.
- Por tick (`HandleMoveAndAttack`): `movingSpeed = CharacterData.Speed / 20` (unidades lógicas por tick); move X e Y clampado a `movingSpeed` até o destino; ao chegar → `m_state = 4`.
- **Colisão com obstáculos** (`CheckObstacle(nextTiles)`): projeta N passos à frente; se tile tem `BlocksMovement && !IsDestructed()` ou sai da play area → obstáculo. **Jogador humano**: para (`StopMovement`) com `CheckObstacle(1)`. **Bot/NPC**: gira o ângulo +2° por tentativa até achar caminho livre (loop `while CheckObstacle(15)`).
- **Empurrão (pushback): NÃO IMPLEMENTADO** (`ChargePushback`, `PushbackStrength` existem nos Data mas não são usados — confirmado pelo README "Fix pushback not being implemented").
- **Stun**: campo `m_isStunned` existe e trava movimento por 40 ticks, mas **nunca é setado para true em lugar algum** → `NÃO ENCONTRADO` uso real.

### C.4 Ataques (`Character.ActivateSkill` → `Skill` → `Character.Attack` → `Projectile`)
1. `ActivateSkill(bool isUlti, int x, int y)`: `m_state = 3`; pega `Skill` (m_skills[0] arma / m_skills[1] ultimate); ignora se já ativa.
   - `BehaviorType == "Blink"`: cria `AreaEffect` no ponto, `SetPosition(x, y, 0)`, cria segundo `AreaEffect` (SkillData.AreaEffectObject/AreaEffectObject2). **Teleporte resolvido aqui**.
   - Senão: `m_angle = LogicMath.GetAngle(x, y)`; `skill.Activate(this, x, y, tileMap)`; `m_attackingTicks = 0`; `ChargeType == 3` calcula `JumpChargeDestination`/`ChargeTime` (**sem consumidor — NÃO IMPLEMENTADO**); se `SkillData.AreaEffectObject` não vazio → spawna `AreaEffect` com `SkillData.Damage`.
2. `Skill.Activate(...)`: consome 1000 de carga (`Charge -= 1000`) se `MaxCharge != 0`; se ultimate → `character.InterruptAllSkills()`; guarda `X/Y` alvo; `TicksActive = 1`; `ActiveTime = SkillData.ActiveTime/50 - 1` (ou `CastingRange/2` para Charge); `character.BlockHealthRegen()`.
3. A cada tick em `Character.HandleMoveAndAttack`, se skill ativa e `BehaviorType == "Attack"`:
   - `Skill.ShouldAttackThisTick()`: tick 0 → `ExecuteFirstAttackImmediately`; senão `TicksActive % (MsBetweenAttacks/50) == 0`.
   - `Character.Attack(skill.X, skill.Y, CastingRange, projectileData, Damage, Spread, NumBulletsInOneAttack, skill)`:
     - Segurar botão (`m_holdingSkill`): >14 ticks → 1 bala; >5 → 3 balas; `GetSkillRangeAddFromHold` (só `AttackPattern == 13`) adiciona alcance.
     - Por bala: `new Projectile(6, projectileData.GetInstanceId())`; `MaxRange = SkillData.CastingRange`; ângulo = `originAngle + GetBulletAngle(i, spread, bulletsPerShot)/(a)` com `a = min(hold,15)/3`; se `IsRapidSpreadPattern` (`AttackPattern == 6`) usa `ATTACK_PATTERN_TABLE = [0, s/6, -2s/6, 2s/6]` com índice circular `SpreadIndex`; `ShootProjectile(angle, this, GetAbsoluteDamage(damage), newRange+1, isUlti)`; anexa `SummonedCharacter` se `SkillData.SummonedCharacter != null`; `AddGameObject`.
     - `ProjectileData == ""` (melee, ex. Primo): **NÃO IMPLEMENTADO** (comentário `//this.StartMeleeAttack() i need to do smth for primo grah`; README: "Fix Primo's attack doing nothing").
   - `BehaviorType == "Invisibility"`: `m_invisible = true` + `DecrementFadeCounter()` (**nunca volta a false — bug reconhecido no README**).
   - `BehaviorType == "Charge"`: **NÃO IMPLEMENTADO** (comentário `//uuh`).
4. **Munição/recarga** (`Skill.Tick`, por tick do dono): `Charge += 1000 / (SkillData.RechargeTime / 50)` até `MaxCharge*1000` (só recarrega se inativa). `HasEnoughCharge()` = `Charge >= 1000` (usado pela IA).
5. **Dano absoluto** (nível de poder): `GetAbsoluteDamage(dmg) = dmg + (5% * dmg) * (m_heroLevel + m_damageMultiplier)`; `SetHeroLevel(level)` também escala HP: `Hitpoints + 5%*Hitpoints*level`. **`HeroPowerLevel` do `BattlePlayer` nunca é preenchido em `Create()` (fica 0)** → em prática, dano/HP base.

### C.5 Projéteis (`Projectile.Tick`)
- **Direto** (`!Indirect`): `HandleCollisions()` todo tick; movimento `delta = Cos(Angle)/20000 * Speed` por eixo (Cos/Sin de `LogicMath` retornam escala 0–20000); `m_totalDelta += Speed/20`; destrói quando `m_totalDelta > CastingTime*180` (o parâmetro `castingTime` recebido é `newRange+1 = range/2+1`).
- **Colisão com tile**: tile `BlocksProjectiles` não destruído → destrói projétil, **exceto** se `IsDestructibleNormalWeapon` ou (`IsDestructible` e projétil de ultimate) → nesses casos `tile.Destruct()` (Quebra-parede por super funciona).
- **Indireto** (arremesso): parábola em Z via `ProjectileData.Gravity`; `FullTravelTicks = distância/(Speed/20)` clampado a `MaxRange`; destrói ao completar; sem colisão em voo.
- Fora da `IsInPlayArea` → destrói + `SetForcedInvisible()`.
- **Colisão com personagem** (`HandleCollisions`): alvo = `ObjectType == 1`, vivo, de time diferente (`GetIndex()/16`), não em `AlreadyDamagedObjectsGlobalIds`, distância ≤ `radius1 + radius2`; se `!PiercesCharacters` → `ShouldDestructImmediately = true`; dano `GetModifiedDamage(Damage)` (interpolação `DamagePercentStart/End` por `m_totalDelta`) **a menos que** o projétil spawne `SpawnAreaEffectObject(2)` (nesses casos o dano vem da área); `ChainBullet` (Jessie) → novo projétil para `character.GetClosestAlly()` (aliado do ALVO — bug "sempre à esquerda" do README); `PoisonDamagePercent != 0` → `AddPoison(source, pct*damage, 4)`; `FreezeStrength >= 1` → `GiveSpeedSlowerBuff` (buff tipo 3).
- **Ao atingir destino** (`TargetReached`, chamado no 1º tick após destruído): spawna `SpawnAreaEffectObject`/`2` como `AreaEffect` e/ou invoca `SummonedCharacter` (turret do Jessie etc.) com `SetIndex(Source.GetIndex())` (mesmo time).
- Destruição definitiva: `ShouldDestruct()` exige `m_destroyedTicks > 2` (o cliente vê o impacto ~3 ticks).

### C.6 Dano (`Character.CauseDamage(Character dealer, int damage, bool shouldShow = true)`)
```
if (m_hitpoints <= 0) return;
if (damage < 0 && m_hitpoints == m_maxHitpoints) return;         // cura sem efeito com HP cheio
if (m_immunity != null) damage -= immunity% * damage;             // reduz percentual
m_hitpoints -= damage;  clamp [0..max];  PoisonBarrel nunca morre por dano (min 1)
if (damage > 0) BlockHealthRegen();                               // trava regen por 60 ticks
if (shouldShow) m_damageIndicator.Add(damage);                    // exibido no próximo VisionUpdate
if (CharacterData.IsHero()):
    dealer != null && != this → enemy.ChargeUlti(dealer.CharacterData, damage); enemy.DamageDealed(damage);
    if (m_hitpoints <= 0):
        battle.PlayerDied(player);
        modo 3 (Bounty): dealer.AddItemsCollected(1); enemy.AddScore(m_itemCount + 1);
        enemy.KilledPlayer(GetIndex() % 16, bountyStars);         // kill feed
        modo 6: dropa Item "BattleRoyaleBuff" na posição da morte;
        modos 0/4: dropa N Itens "Point" (N = m_itemCount) — gemos caem no chão;
if (m_hitpoints == 1 && Name == "PoisonBarrel"): TODOS os PoisonBarrels ganham timer de morte 4*20 ticks;
if (m_hitpoints <= 0):
    if (CharacterData.DeathAreaEffect != null) → CreateAreaEffect;
    if (Type == "LootBox") → dropa "Point" (ou "BattleRoyaleBuff" no modo 6);
```
- **Cura**: dano negativo (`CauseDamage(this, -RegeneratePerSecond, false)`).
- **Cura passiva** (`TickHeals`, só heróis): se HP < max, sem dano por 60 ticks (3 s) e passou 20 ticks desde a última cura → cura `13% do HP máx` por segundo (`GetRegeneratePerSecond`); contabiliza `player.Healed()`.

### C.7 Imunibilidade / veneno / buffs
- `Immunity(ticks, %)`: spawn de herói usa `SetImmunity(60, 100)` = **100% de redução por 3 s**.
- `Poison(source, damage, tickCount)`: aplica `damage/tickCount` a cada 20 ticks (1 s), `RefreshPoison` renova; usada por `ProjectileData.PoisonDamagePercent`.
- `Buff(Type, Duration, Modifier, SizeInc)`: tipos 1 Damage, 2 DamageAndSize, 3 SpeedSlower, 4 SpeedFaster, 5 Damage2, 10 HealthRegen; **só afeta velocidade de verdade** (`GetBuffedSpeed` soma modifiers dos tipos 3,4,6 — máscara 88). `CanStack` só tipo 10. `GiveSpeedSlowerBuff` aplica tipo 3 (slow). **Buff de dano NÃO afeta o dano real** (README: "slow down effect not doing anything" / mecânicas não implementadas).

### C.8 Morte e respawn
`BattleMode.PlayerDied(BattlePlayer player)`:
- **Modo 6 (BattleRoyale)**: `rank = m_playersAlive--`; `player.BattleRoyaleRank = rank`; envia **imediatamente** `BattleEndMessage` (GameMode 5, Result = rank, Tokens = 40/rank, troféus `(5-rank)*2` se rank ≤ 5, senão `-(rank-5)` clampado aos troféus do herói); `Avatar.BattleId = -1`; **sem respawn**.
- **Demais modos**: modos 0/4 → `player.ResetScore()` (perde as gemas); `player.OwnObjectId = 0`; enfileira `DiedEntry{DeathTick = GetTicksGone()}`.
`TickSpawnHeroes()` (todo tick): para cada `DiedEntry`, se `GetTicksGone() - DeathTick >= GetRespawnSeconds(variation)*20` → cria novo `Character` (mesmo `PlayerIndex + 16*TeamIndex`), posição = `player.GetSpawnPoint()`, `SetBot`, `SetImmunity(60,100)`, `AddGameObject`, atualiza `player.OwnObjectId` e `m_playersByObjectGlobalId.Add(...)`.
`GetRespawnSeconds`: **3 s** (modos 0, 2), **1 s** (modo 3), **5 s** (padrão).
*(Nota: a entrada antiga em `m_playersByObjectGlobalId` nunca é removida — fica órfã.)*

### C.9 Itens (`Item` → `PickUp` → `ApplyItem`)
- Herói pega item a **distância < 350** (`HandleMoveAndAttack`); `Item.PickUp(character)` → item voa até o dono por 4 ticks → `ApplyItem`:
  - `"BattleRoyaleBuff"` (Power Cube): +10% HP máx, cura igual, `m_damageMultiplier++`, `m_itemCount++` (só modo 6).
  - `"Money"`: `player.AddScore(1)` (CoinRush — pontuação de time).
  - `"Point"` (gema): `m_itemCount++` + `player.AddScore(1)` (modos 0 e 4).
- Spawn de gemas: modo 0 → a cada 100 ticks (5 s) no centro **(3150, 4950)** com ângulo aleatório; modo 4 → 1 gema no tick 600.
- `"BoxOfMines"`: explode em 3 `"Mine"`. Animação de aparecimento: 10 ticks deslizando + 4 ticks de pulo em Z.

### C.10 Objetos iniciais (`BattleMode.AddGameObjects`)
- Cada player: `Character` com `SetIndex(PlayerIndex + 16*TeamIndex)`, spawn em `TileMap.SpawnPointsTeam1/2[indexer++]` (times separados; no BR todos no time 1), `SetImmunity(60, 100)`.
- Cada tile `LootBoxes`: modo 6 → `LootBox` com **50% de chance** (`GetRandomInt(0,120) < 60`); senão `ExplodingBarrel` (index 22 = time inimigo).
- Cada tile `PoisonBarrels` → `PoisonBarrel` (index 22).
- Modo 0/4/-1 → `Item "OrbSpawner"` no centro (3150,4950) sem animação.
- Modo 2 (Heist) → `Character Safe1..Safe4` (tile '6'-'9') no tile `Safe`, index 22 (inimigo).
- Modo 3 → `Item "Money"` no centro. Modo 5 → `Character "LaserBall"` no centro (index 0).

### C.11 Zona venenosa do Showdown (`IsTileOnPoisonArea`)
Somente modo 6. Após tick 500 (25 s): `poisons = (tick-500)/100` (1 tile a cada 5 s); tile está no veneno se `x <= poisons || x >= 59-poisons || y <= poisons || y >= 59-poisons` (mapa presumido 60×60). `Character.TickTile` aplica **250 de dano por segundo** (checa a cada 20 ticks) com `CauseDamage(null, 250)`.

### C.12 Bushes / visibilidade (`FadeCounter`)
- `FadeCounter` 0–10 por objeto. Em tile `HidesHero` (bush) não destruído → `DecrementFadeCounter()`; fora → `IncrementFadeCounter()`.
- `GameObjectManager.GetVisibleGameObjects(teamIndex)`: objeto visível se `FadeCounter > 0` **ou** `GetIndex()/16 == teamIndex` (aliados sempre visíveis).
- Inimigo a ≤ 200 de distância → `SetForcedVisible()` (FadeCounter = 10).
- Projétil fora da área → `SetForcedInvisible()`.

### C.13 IA (bots e NPCs) — `Character.TickAI` (só após `INTRO_TICKS = 80`)
- **`m_isBot`** → `TickBot()`: reencontra inimigo mais próximo a cada 60 ticks (`GetClosestEnemy`); a cada 40 ticks `MoveTo(inimigo ± 200 aleatório)`; ataca se distância < `CastingRange*80` e cooldown de 20 ticks respeitado; usa ultimate se `player.HasUlti()` (carga ≥ 1000); `ActivateSkill(false, deltaX, deltaY)`.
- `TickBotArtTest()`: variante para `m_ART_TEST` (desligado).
- **NPCs não-herói**: `Minion_FindEnemies`/`Minion_Dog` perseguem `GetClosestEnemy()` e usam `StartMeleeAttack(target, 10 ticks, AutoAttackDamage)` (dano aplicado ao fim, `CauseDamage(null, dmg)`); personagens com `AutoAttackProjectile` atiram projétil automático em qualquer inimigo a `100*AutoAttackRange` com cadência `AutoAttackSpeedMs/50`.
- Bots recebem `BattlePlayer.CreateBotInfo("Bot "+i, ...)` com `SessionId = -1`, `AccountId = 100000+index`, personagem aleatório de `botBrawlers = {0..16}` (17 brawlers), **sem repetição dentro do mesmo time** (nos modos 2 times).

### C.14 Condições de fim (`CalculateIsGameOver`)
- Se `m_ART_TEST && variation != 5` ou `m_BATTLE_SIM` → nunca termina (debug).
- Limite de tempo: `GetTicksGone() >= GetBattleTicks(variation)` (3600 ou 16000) → **true** (com `m_winnerTeam` intocado = -1 → empate).
- Antes do tempo:
  - **2 (Heist)**: algum `Character` com `CharacterData.IsBase()` morto → `m_winnerTeam` = time oposto ao do cofre (`GetIndex()/16`).
  - **3 (Bounty)**: em `20*120+120 = 2520` ticks (126 s) → maior `GetTeamScore` vence (empate = -1).
  - **0 (GemGrab)**: time com score ≥ 10 inicia countdown de `20*17` ticks (17 s); mantém a liderança até o fim → vence; perde a condição → countdown resetado a 0. Score = soma de `player.GetScore()` do time (gemas carregadas).
  - **4 (Artifact)**: score ≥ 1 + countdown `20*30` (30 s).
  - **6 (Showdown)**: `m_playersAlive <= 1`.
  - default → false.

### C.15 Recompensas (`SendBattleEndToPlayers`)
Para cada player com `SessionId >= 0` e `IsAlive` (BR: rank `-1` → 1):
- `Avatar.BattleId = -1`.
- `message.GameMode = 1` (normal) ou `2` (BR); `Result`: 0 vitória / 1 derrota / 2 empate / rank no BR.
- Tokens: vitória 20, derrota 10, empate 10, BR `40/rank`.
- Troféus: vitória `rand.Next(5,8)+1` (6–8); derrota **-2** clampado aos troféus do herói; empate 0; BR `(5-rank)*2` ou `-(rank-5)` clampado. Aplicados direto em `hero.AddTrophies(...)` (persistidos pelo `AccountCache` a cada 30 s).
- `Avatar.AddChips(tokens)` — **corpo vazio (no-op)**. `Avatar.TrioWins++` na vitória. `Home.TokenReward`/`TrophiesReward` acumulam para a tela home (mas `ClientHome.Tick()` zera a cada `EndClientTurnMessage` — comportamento real do código).
- Enviado por `player.GameListener.SendTCPMessage(message)` → no `UDPGameListener` isso cai no **TCP** (`TCPConnection.Send`).

---

## D — FLUXO COMPLETO (as 24 etapas do enunciado, com rastreio real)

Formato: `arquivo → classe.método → próximo → resultado`

**1–3. Solicitar/encontrar partida + seleção de jogadores**
```
Cliente (TCP, RC4) → Messaging.OnReceive() → ReadNewMessage() → MessageFactory.CreateMessageByType(14103)
→ Processor.Receive() [fila 1024] → Processor.UpdateReceive() → MessageManager.ReceiveMessage()
→ MessageManager.MatchmakeRequestReceived(MatchmakeRequestMessage)
   (valida: HomeMode.Home.CharacterId = message.SelectedCard; Home.Character.Disabled → OutOfSyncMessage)
→ Matchmaking.RequestMatchmake(Connection, slot)
   → SLOTS SÃO REINICIADOS A CADA REQUEST (bug real: "Slots = new Dictionary<...>()" incondicional)
   → cria/reusa MatchmakingSlot(evento, playersRequired) → slot.Add(new MatchmakingEntry(connection))
```
- `Events.Init()` (boot + timer 60 min) gera `EventData` por slot a partir de `gameplay.json` (slot 1,2 = BattleRoyale; 3 = BountyHunter; 4 = CoinRush) sorteando `LocationData` do modo permitido (exclui "Tutorial").
- `MatchmakingSlot.Update()` (thread 250 ms): remove conexões fechadas; move `RequestQueue`→`Queue`; `Queue.Count >= PlayersRequired` (10 BR / 6 demais) → `StartGame(Queue.Take(N))`; senão countdown `SEARCH_TIMEOUT = 20 s` (decrementado a cada 4 updates ≈ 1 s) → `StartGame` com quem houver; broadcast `MatchMakingStatusMessage` (20405) aos que esperam.
- **Times prontos (premade)**: `TeamCreateMessage`(14350) → `Teams.Create()` → `TeamMessage`(24124) a todos; `TeamSetMemberReadyMessage`(14355) → `TeamSetMemberReadyReceived` → se `team.IsEveryoneReady()` → `Teams.StartGame(team)` → para cada membro: `TeamGameStartingMessage`(24130) + `Matchmaking.RequestMatchmake(connection, team.EventSlot, team.Id)`.

**4–5. Criação da GameRoom e entrada dos jogadores**
```
MatchmakingSlot.StartGame(entries)
→ new BattleMode(EventData.LocationId)            [CRIA A SALA]
→ battle.Id = Battles.Add(battle)                  [REGISTRO]
→ (2 times) agrupa por PlayerTeamId → PrefferedTeam; solos no fim
→ POR PLAYER HUMANO:
    UDPSocket socket = UDPGateway.CreateSocket()   [++SessionCounter, dict]
    socket.TCPConnection = connection; socket.Battle = battle
    connection.UdpSessionId = socket.SessionId
    teamIndex = i % 2 (ou PrefferedTeam; cap 3 por time, troca se cheio)   [BR: teamIndex = i]
    BattlePlayer player = BattlePlayer.Create(Home, Avatar, i, teamIndex)
    battle.AddPlayer(player, socket.SessionId)
       → player.Avatar.BattleId = Id; TeamIndex; OwnIndex; m_playersBySessionId[...]
→ BOTS até GetPlayersCountWithGameModeVariation(): BattlePlayer.CreateBotInfo(...) → battle.AddPlayer(bot, -1)
```

**6–8. Times, mapa/modo e inicialização**
- Times: derivados de `TeamIndex` (ver B.3). Mapa: `Location.AllowedMaps` → `TileMapFactory.CreateTileMap` (lê `Assets/tilemaps.json`: WIDTH/HEIGHT/Data ASCII; códigos '1'/'2' spawn, '4' loot box, '5' poison barrel, '6'–'9' safes; resto casa com `TileData.TileCode` de tiles.csv).
- `battle.AddGameObjects()` → heróis + objetos do modo (C.10).

**9–10. Estado inicial enviado e início**
```
MatchmakingSlot.StartGame()
→ StartLoadingMessage (20559, TCP): Players[], OwnIndex, TeamIndex, GameMode(6 se BR senão 1),
  LocationId(ref), control mode 1, SpectateMode ausente(0)
→ connection.Avatar.UdpSessionId = socket.SessionId
→ battle.Start() → new Timer(Update, null, 0, 1000/20)   [LOOP 20 TPS COMEÇA]
```
O cliente então envia `ClientInfoMessage`(10177) por TCP → `ClientInfoReceived` → **`UdpConnectionInfoMessage`(24112)** com sessionId + udp_host/udp_port → cliente passa a mandar inputs por UDP.

**11. Loop/tick** — ver C.1 (`BattleMode.ExecuteOneTick`).

**12–14. Comandos → processamento → atualização de estado**
```
Cliente (UDP plaintext) → UDPGateway.ReceiveCallback()
   [primeiro pacote: SetEndPoint + player.GameListener = new UDPGameListener(socket, TCPConnection)]
→ UDPSocket.ProcessReceive(ByteStream)  [Task.Run]
→ MessageFactory → ClientInputMessage(10555).Decode()  [fila de ClientInput]
→ UDPSocket.HandleMessage() → Battle.AddClientInput(input, SessionId) → m_inputQueue
   [espectador: Battle.HandleSpectatorInput → apenas ack HandledInputs]
→ (próximo tick) BattleMode.HandleIncomingInputMessages → HandleClientInput → C.2
```
**CANAL DUPLO**: `SendMessage` = UDP (VisionUpdate), `SendTCPMessage` = TCP (BattleEnd) — ver `UDPGameListener`.

**15–18. Ataques, dano, mortes, respawn** — C.4, C.6, C.8.

**19. Sincronização de eventos**
```
BattleMode.SendVisionUpdateToPlayers()
→ Parallel.ForEach(m_players):
     BitStream(64) → GameObjectManager.Encode(bs, tileMap, player.OwnObjectId, player.PlayerIndex, player.TeamIndex)
     VisionUpdateMessage { Tick, HandledInputs = player.LastHandledInput, Viewers = m_spectators.Count, VisionBitStream }
     player.GameListener.SendMessage(message)   [UDP]
→ espectadores: stream com ownObjectGlobalId=0, playerIndex=-1, teamIndex=-1 → Task.Run envia a todos
```
Layout do bitstream (ordem exata em `GameObjectManager.Encode` + `GameObject.Encode` + subclasses):
```
WritePositiveInt(ownObjectGlobalId, 21)
WritePositiveInt(m_gemGrabCountdown, 15)
WriteBoolean(false)
[modo != 6] 0(5 bits), 0(6), width-1(5), height-1(6)   |   [modo 6] 0(6), 0(7), width-1(6), height-1(7)
para cada tile com RespawnSeconds>0 || IsDestructible: WriteBoolean(tile.IsDestructed())
para cada player: 0(1 bit), WriteBoolean(HasUlti), [se i==playerIndex] GetUltiCharge(10 bits)
switch modo: 6 → PlayersAlive(4) | 2 → HP% cofre time0(7) + HP% cofre time1(7) | 3 → 100(3), 100(3)
para cada player: GetScore(6), KillList.Count(2 bits), por kill: 1(3 bits), BountyStarsEarned(4 bits)
WritePositiveInt(visibleObjects.Count, 7)
para cada objeto: WriteDataReference (classId 5 bits + instanceId 8 bits)
para cada objeto: WriteObjectRunning (classId 5 bits + instanceId 14 bits)
para cada objeto: gameObject.Encode(bs, isOwn, visionTeam):
   GameObject: X(13/15), Y(14/16), Index(7/8), Z(12)
   Character: fade(4) [10 se próprio time]; se AutoAttackDamage!=0 || Speed!=0:
       [own] bool false | [outro] angle(9)x2; state(3); slow(bool); false; false;
       attackingTicks(6); false; false; false; poisoned(bool); 0(7); 0(5)
       [senão apenas state(3)]
       hitpoints(11 ou 13 no modo 6/HP>1599), maxHitpoints(idem)
       [herói] itemCount(7 no modo 3, senão 6) [+bool false se modo 5]; 0(13); 0(11);
       chargeActive(bool); immunity(bool); false; false; usingUlti(bool); false;
       [se charge] chargeType(10)   [Minion_Dog: size(5)]
       invisible(bool); invisible(bool); 0(9); [own] false + 0(9)
       damageIndicator.Count(5); por dano: isDamage(bool) + abs(dano)(12)
       por skill: Skill.Encode → TicksActive(11), false, 0(12), [MaxCharge>=1] Charge(12)
   Projectile: efeito(3) [0 nada, 1 fim de alcance, 3 destruído]; [IsBouncing] bool+0(10/14);
       [TriggerWithDelayMs/PreExplosionTimeMs] 0(14); [PreExplosion] 0(13)+0(14);
       0(10) "Total path"; [OnDeploy] 0(13)+0(14)
   AreaEffect / Item: 10(4 bits); Item: [OrbSpawner] 0(14)x2 | [Mine] 0(11)x2
```
`VisionUpdateMessage.Encode()`: `VInt(Tick)`, `VInt(HandledInputs)`, `VInt(1)` ("command count" hardcoded, nenhum comando escrito), bytes crus do BitStream.

**20–22. Vitória/derrota → resultado → encerramento** — C.14, C.15; encerramento = `m_updateTimer.Dispose()` + `IsGameOver = true`.

**23. Remoção de jogadores** — **NÃO EXISTE saída individual de jogador durante a batalha**: desconectado = personagem fica parado até o fim; `Avatar.BattleId = -1` só no fim (ou na morte no BR). Re-login durante a batalha → `LoginReceived`: `Avatar.BattleId > 0` → `Battles.Get` → novo `UDPSocket` + `battle.ChangePlayerSessionId(old, new)` (reseta `LastHandledInput = 0`) + `StartLoadingMessage` de volta (reconexão). `GoHomeMessage`(14101) durante a batalha apenas re-envia `OwnHomeDataMessage` (não sai da batalha).

**24. Liberação de recursos** — `Battles.Update()` (thread 1 s) remove a sala do dicionário quando `IsGameOver`; **UDPGateway.Sockets nunca remove sockets** (vazamento real); Timer disposed no fim.

---

## E — PACOTES / OPCODES / HANDLERS

**Framing TCP**: header 7 bytes = `type(2) | length(3) | version(2)`, payload **RC4** (`RC4Encrypter`: chave hardcoded `"c2GJQU5hCjW56525cLA9MQ9JINk3zZk4nJsjYq" + "nonce"`, skip do keyNonce; `Settings.json` é lido mas a chave do arquivo é ignorada).
**Framing UDP** (sem criptografia): `Long sessionId | Short 0 | VInt type | VInt length | bytes`.
Filas do `Processor`: cap 1024 itens, 2 threads (recv/send) com `ManualResetEvent`.

### E.1 CLIENTE → SERVIDOR (todos os registrados no `MessageFactory`/`MessageManager`)
| Opcode | Mensagem (arquivo em `Logic/Message/`) | Handler (`MessageManager`, exceto onde indicado) | Efeito na batalha |
|---|---|---|---|
| **10101** | `AuthenticationMessage` (Account/Auth) | `LoginReceived` | login; **reconexão de batalha** via `Avatar.BattleId` |
| 10107 | `ClientCapabilitiesMessage` | `ClientCapabilitesReceived` | ping |
| 10108 | `KeepAliveMessage` | inline | reseta `LastKeepAlive` (30 s de vida) + `KeepAliveServerMessage` |
| **10177** | `ClientInfoMessage` (Udp) | `ClientInfoReceived` | devolve `UdpConnectionInfoMessage` (24112) com sessão UDP |
| 10212 | `ChangeAvatarNameMessage` | `ChangeName` | home |
| 10501/10502/10504/10506 | Friends | `AcceptFriendReceived`/`AddFriendReceived`/`AskForFriendListReceived`/`RemoveFriendReceived` | social |
| **10555** | `ClientInputMessage` (Battle) — **via UDP** | `UDPSocket.HandleMessage` (TCP: case 10555 = break) | **inputs da batalha** → `Battle.AddClientInput` |
| 14101 | `GoHomeMessage` | `GoHomeReceived` | reenvia OwnHomeData |
| 14102 | `EndClientTurnMessage` | `EndClientTurnReceived` → `HomeMode.ClientTurnReceived` (comandos 500/506/507/1000) | home-state (não batalha) |
| **14103** | `MatchmakeRequestMessage` | `MatchmakeRequestReceived` | **entra no matchmaking** (SelectedCard + EventSlot) |
| **14104** | `StartSpectateMessage` (Battle) | `StartSpectateReceived` | espectatar batalha por AccountId |
| **14106** | `CancelMatchmakingMessage` | `CancelMatchMaking` → `Matchmaking.CancelMatchmake` | sai da fila (cascata para o time) |
| **14107** | `StopSpectateMessage` | `StopSpectateReceived` | remove espectador + OwnHomeData |
| 14109 | `GoHomeFromOfflinePractiseMessage` | `GoHomeFromOfflinePractiseReceived` | home |
| 14113 | `GetPlayerProfileMessage` | `GetPlayerProfile` | perfil |
| 14166 | `ChronosEventSeenMessage` | (ignorado, break) | — |
| 14301–14316 | Alliance (7 mensagens) | vários | clubes |
| **14350** | `TeamCreateMessage` | `TeamCreateReceived` | cria `TeamEntry` |
| **14353** | `TeamLeaveMessage` | `TeamLeaveReceived` | sai do time |
| **14354** | `TeamChangeMemberSettingsMessage` | `TeamChangeMemberSettingsReceived` | troca de brawler no time |
| **14355** | `TeamSetMemberReadyMessage` | `TeamSetMemberReadyReceived` | **dispara `Teams.StartGame`** quando todos prontos |
| 14359/14369 | `TeamChatMessage`/`TeamPremadeChatMessage` | chat do time | stream do time |
| 14361 | `TeamMemberStatusMessage` | `TeamMemberStatusReceived` | status membro |
| **14362** | `TeamSetEventMessage` | `TeamSetEventReceived` | escolhe evento do time (slot != 2) |
| 14363 | `TeamSetLocationMessage` | `TeamSetLocationReceived` | team.Type = 1 |
| 14365 | `TeamInviteMessage` | `TeamInviteReceived` | convite |
| 14366 | `PlayerStatusMessage` | `PlayerStatusReceived` | status p/ amigos |
| 14403 | `GetLeaderboardMessage` | `GetLeaderboardReceived` | ranking |
| 14479 | `TeamInvitationResponseMessage` | `TeamInvitationResponseReceived` | aceitar convite |
| 14600 | `AvatarNameCheckRequestMessage` | `AvatarNameCheckRequestReceived` | renomear |

### E.2 SERVIDOR → CLIENTE (envolvidas na batalha; em negrito as exclusivas do fluxo de batalha)
| Opcode | Mensagem | Quem envia | Momento / conteúdo |
|---|---|---|---|
| 20104 | `AuthenticationOkMessage` | `LoginReceived` | login ok (AccountId, PassToken, versão 1/1714) |
| 20103 | `AuthenticationFailedMessage` | login/cancel/erro | falha (códigos 1, 10, 11) |
| 20108 | `KeepAliveServerMessage` | keepalive | resposta |
| 20161 | `ShutdownStartedMessage` | `Sessions.StartShutdown` | manutenção |
| **20405** | `MatchMakingStatusMessage` | `MatchmakingSlot.Update` (a cada ~1 s) | Seconds, Found, Max, "dudka" xN, Status |
| 20406 | `MatchMakingCancelledMessage` | **NUNCA ENVIADA (classe existe, sem chamadas)** | — |
| **20559** | `StartLoadingMessage` | `MatchmakingSlot.StartGame`, `StartSpectateReceived`, `LoginReceived`(rejoin) | início de carregamento: players codificados (`BattlePlayer.Encode`: AccountId, nome, PlayerIndex, TeamIndex, CharacterId ref), OwnIndex, TeamIndex, GameMode, LocationId ref |
| **23456** | `BattleEndMessage` | `BattleMode.PlayerDied` (BR) e `SendBattleEndToPlayers` | resultado, recompensas, lista de players, milestones (`Settings.json → MaximumRank`) |
| 24101 | `OwnHomeDataMessage` | vários | home (eventos `EventData.Encode` incluídos) |
| 24104 | `OutOfSyncMessage` | `HomeMode.ClientTurnReceived`, checks de brawler disabled | 3 VInt zero |
| **24109** | `VisionUpdateMessage` | `BattleMode.SendVisionUpdateToPlayers` (20 Hz, UDP) | Tick + HandledInputs + bitstream de visão (C.19) |
| 24111 | `AvailableServerCommandMessage` | comandos home | — |
| **24112** | `UdpConnectionInfoMessage` | `ClientInfoReceived`, `StartSpectateReceived` | port, host, sessionId (Long), nonce 0 |
| 24113 | `PlayerProfileMessage` | perfil | — |
| **24124** | `TeamMessage` | `TeamEntry.TeamUpdated` | estado do time |
| **24125** | `TeamLeftMessage` | `TeamLeaveReceived` | saiu do time |
| **24130** | `TeamGameStartingMessage` | `Teams.StartGame` | "jogo começando" (LocationId ref) |
| 24131 | `TeamStreamMessage` | `TeamEntry.AddStreamEntry` | chat do time |
| 24301–24399 | Alliance (6) | handlers de clube | — |
| 24403 | `LeaderboardMessage` | ranking | — |
| 24555 | `FriendOnlineStatusEntryMessage` | status de amigo | — |
| 24589 | `TeamInvitationMessage` | `TeamInviteReceived` | convite |
| 25892 | `DisconnectedMessage` | `Sessions.Create` (sessão duplicada) | Reason 1 |

**Comandos home** (`CommandManager`, dentro de 14102): 500 `LogicGatchaCommand`, 506 `LogicSetPlayerThumbnailCommand`, 507 `LogicSelectSkinCommand`, 1000 `LogicDebugCommand`. **Nenhum comando de batalha existe por TCP** — inputs vão só por UDP (10555).

---

## F — DEPENDÊNCIAS (cadeias completas até a implementação final)

```
BattleMode
 ├─ GameObjectManager ──────────→ BattleMode (referência circular p/ GetBattle)
 │    ├─ GameObject (base) ─────→ GlobalId, LogicVector2, BitStream
 │    ├─ Character ────────────→ CharacterData / SkillData (DataTables 16/20)
 │    │      ├─ Skill ──────────→ SkillData (RechargeTime, ActiveTime, Spread, AttackPattern...)
 │    │      ├─ Buff / Immunity / Poison (Component/)
 │    │      ├─ Projectile ─────→ ProjectileData (DataTables 6), TileMap/Tile (colisão)
 │    │      ├─ AreaEffect ─────→ AreaEffectData (DataTables 17)
 │    │      └─ Item ───────────→ ItemData (DataTables 18) → Character.ApplyItem
 │    └─ BitStream/ByteStreamHelper (serialização da visão)
 ├─ TileMap / Tile / Rect / TileMapFactory → tiles.csv (TileData, tabela 27) + tilemaps.json (LogicJSONParser)
 ├─ BattlePlayer ───────────────→ ClientHome / ClientAvatar / Hero (trophies), PlayerDisplayData, PlayerKillEntry
 ├─ ClientInput (fila)          → decodificado por ClientInputMessage (UDP)
 ├─ LogicGameListener (abstrato)→ implementado por HomeGameListener (TCP) e UDPGameListener (UDP+TCP)
 ├─ GameTime, LogicRandom(0), LogicMath/LogicVector2 (Titan)
 ├─ GameModeUtil / GamePlayUtil → variação de modo, ticks, respawn, contagem de players
 └─ BattleEndMessage / VisionUpdateMessage / StartLoadingMessage → ByteStream (Titan)
Matchmaking ─→ Events (gameplay.json) ─→ EventData ─→ LocationData (locations.csv)
            ─→ UDPGateway.CreateSocket ─→ UDPSocket
            ─→ BattlePlayer.Create/CreateBotInfo ─→ CharacterData (validação do brawler)
Battles (registry) ─→ ConcurrentDictionary<long, BattleMode>
TCPGateway ─→ Connection ─→ Messaging (RC4Encrypter/CryptoRC4) ─→ Processor ─→ MessageManager
UDPGateway ─→ UDPSocket ─→ MessageFactory ─→ ClientInputMessage ─→ BattleMode.AddClientInput
Sessions ─→ Session ─→ HomeMode ─→ HomeGameListener
```

**Cadeia completa de um ataque** (exemplo real):
```
UDPGateway.ReceiveCallback → UDPSocket.ProcessReceive → UDPSocket.HandleMessage
→ BattleMode.AddClientInput → (tick) BattleMode.HandleClientInput [type<100, é UltimateSkill]
→ BattlePlayer.UseUlti() [zera carga] → Character.ActivateSkill(true, dx, dy)
→ Skill.Activate (consome 1000 de carga, TicksActive=1, ActiveTime=ActiveTime/50-1)
→ (tick seguinte) Character.HandleMoveAndAttack → Skill.ShouldAttackThisTick
→ Character.Attack → DataTables.Get(6).GetData<ProjectileData>(SkillData.Projectile)
→ new Projectile(6, id).ShootProjectile(angle, this, GetAbsoluteDamage(dmg), range/2+1, true)
→ GameObjectManager.AddGameObject
→ Projectile.Tick → HandleCollisions → Character.CauseDamage
→ BattlePlayer.ChargeUlti (dealer) / DamageDealed / [se HP≤0] BattleMode.PlayerDied
→ (tick) BattleMode.SendVisionUpdateToPlayers → GameObjectManager.Encode → VisionUpdateMessage
→ UDPGameListener.SendMessage → UDPSocket.SendMessage → UDPGateway.SendTo → CLIENTE
```

---

## G — CICLOS DE VIDA (estados REAIS)

### G.1 GameRoom (não há enum de estados; estados implícitos)
```
CREATE          MatchmakingSlot.StartGame: new BattleMode(locationId) + Battles.Add → Id
FILL            AddPlayer (humanos com UdpSessionId, bots com -1) + AddGameObjects (heróis, caixas, cofres, itens)
NOTIFY          StartLoadingMessage(20559) por TCP para cada humano
RUNNING         battle.Start() → Timer 20 TPS → ExecuteOneTick (loop até CalculateIsGameOver)
END             m_updateTimer.Dispose() + GameOver() → SendBattleEndToPlayers (23456) [ou exceção → fim silencioso]
CLEANUP/GC      Battles.Update thread (1 s): m_battles.Remove(Id) → GC (UDPSockets NÃO são liberados)
```

### G.2 Player (fluxo real)
```
LOGIN           TCP 10101 → LoginReceived → HomeMode.LoadHomeState → OwnHomeDataMessage(24101)
                [se Avatar.BattleId>0 e batalha viva → REJOIN: StartLoading + novo UDPSocket + ChangePlayerSessionId]
LOBBY/TEAM      TeamCreate(14350) → TeamSetMemberReady(14355) → Teams.StartGame → TeamGameStarting(24130)
MATCHMAKING     MatchmakeRequest(14103) → Matchmaking.RequestMatchmake → slot.Add(entry)
                [status 20405 a cada ~1 s; timeout 20 s → segue com bots]
BATTLE JOIN     StartGame: UDPSocket criado + BattlePlayer.Create + battle.AddPlayer
LOADING         StartLoadingMessage(20559) → ClientInfoMessage(10177) → UdpConnectionInfoMessage(24112)
IN-BATTLE UDP   1º pacote UDP → GameListener trocado p/ UDPGameListener → 10555 inputs → m_inputQueue
SPAWN           AddGameObjects/TickSpawnHeroes: Character com Immunity(60 ticks, 100%)
PLAYING         tick 20 Hz: inputs → skills → projéteis → dano → visão (24109 a cada tick)
ULTI            ChargeUlti por dano causado (UltiChargeMul*dmg/UltiChargeDiv, cap 1000) → UseUlti
DEATH           PlayerDied → [BR: BattleEndMessage imediato + fim] / [demais: DiedEntry + respawn 1/3/5 s]
GAME END        CalculateIsGameOver → SendBattleEndToPlayers → BattleEndMessage(23456, TCP)
LEAVE/AFTER     Avatar.BattleId = -1; cliente envia GoHome(14101) → OwnHomeDataMessage
DISCONNECT      TCP cai → Connections/Sessions removidos (30 s sem keepalive ou erro de socket);
                DENTRO da batalha NÃO há remoção do player (personagem fica parado até o fim)
```

### G.3 Battle (objeto `Character` de cada jogador)
```
spawn (AddGameObjects/TickSpawnHeroes) → INTRO (80 ticks sem IA/regen) → combate
→ morte (CauseDamage → PlayerDied) → [respawn] ou [fim no BR]
```

---

## H — ARQUITETURA FINAL (somente componentes que existem no repo)

```
CLIENTE BRAWL STARS 1.1714 (IPA com IP patcheado)
   │  TCP 9339 (RC4)                         │  UDP 9449 (plaintext, sessionId)
   ▼                                          ▼
TCPGateway.OnAccept                      UDPGateway.ReceiveCallback
   → Connection(socket)                     → Sockets[sessionId] (UDPSocket)
   → Messaging (framing 7B + RC4)            → 1º pacote: UDPGameListener instalado no player
   ▼                                          ▼
Processor (filas recv/send, 2 threads)   UDPSocket.ProcessReceive (Task.Run)
   ▼                                          ▼
MessageManager.ReceiveMessage           UDPSocket.HandleMessage (só 10555)
   ├─ Login/Team/Alliance/Home            ▼
   ├─ 14103 Matchmake ────────┐          BattleMode.AddClientInput → m_inputQueue
   ├─ 14355 Ready ── Teams ───┤                 ▲
   └─ 14104 Spectate ── Battles┤                 │ (a cada 50 ms)
                              ▼                 │
                     MATCHMAKING (Slots 250 ms, timeout 20 s, bots)
                              ▼
              MatchmakingSlot.StartGame   ──────┤
               ├─ new BattleMode (GAMEROOM)
               ├─ Battles.Add (registry/GC 1 s)
               ├─ UDPGateway.CreateSocket por player
               ├─ BattlePlayer.Create / CreateBotInfo
               ├─ battle.AddPlayer / AddGameObjects (TileMapFactory, tilemaps.json)
               ├─ StartLoadingMessage (20559, TCP)
               └─ battle.Start() ───────────────┤
                              ▼                 │
                     BATTLEMODE.ExecuteOneTick (Timer 20 TPS)
                      ├─ HandleIncomingInputMessages → HandleClientInput
                      │    → Character.MoveTo / ActivateSkill / UltiEnabled...
                      ├─ CalculateIsGameOver → GameOver → SendBattleEndToPlayers (23456)
                      ├─ GameObjectManager.PreTick / Tick
                      │    ├─ Character.Tick (move, ataque, skills, buffs, veneno,
                      │    │     imunidade, regen, tiles, IA/bots, pickups)
                      │    ├─ Projectile.Tick (voo, colisão, dano, chain, área)
                      │    ├─ AreaEffect.Tick (Damage/Dot/Hot/BulletExplosion)
                      │    └─ Item.Tick (animação, pickup, BoxOfMines)
                      ├─ TileMap.Tick (vazio) / TickSpawnHeroes (respawn) / TickSpawnEventStuffDelayed
                      ├─ GameTime.IncreaseTick
                      └─ SendVisionUpdateToPlayers
                           └─ GameObjectManager.Encode (BitStream) → VisionUpdateMessage (24109)
                                → player.GameListener (UDPGameListener) → UDPSocket → UDP → CLIENTE
                                   BattleEndMessage → SendTCPMessage → TCP → CLIENTE
PERSISTÊNCIA: Hero.AddTrophies/Avatar → AccountCache.SaveAll (30 s) → MySQL `accounts`
```

---

## I — ARQUIVOS ESSENCIAIS PARA PORTAR/REIMPLEMENTAR A BATALHA

**CORE (sem isso não existe batalha):**
1. `Logic/Battle/BattleMode.cs` — a GameRoom inteira (tick, regras, fim, recompensas, visão)
2. `Logic/Battle/Objects/GameObjectManager.cs` — mundo + serialização da visão
3. `Logic/Battle/Objects/Character.cs` — entidade viva completa (movimento/ataque/IA/dano)
4. `Logic/Battle/Objects/Projectile.cs` — projéteis/colisão
5. `Logic/Battle/Objects/AreaEffect.cs` + `Item.cs` — áreas de efeito e itens
6. `Logic/Battle/Structures/BattlePlayer.cs` (+ `PlayerKillEntry.cs`) — estado por jogador
7. `Logic/Battle/Component/Skill.cs` (+ `Buff`, `Immunity`, `Poison`) — munição/recarga/status
8. `Logic/Battle/Input/ClientInput.cs` — formato do input
9. `Logic/Battle/Level/*` (`TileMap`, `Tile`, `Rect`, `TileMapFactory`) — mapa
10. `Server/Logic/Game/Matchmaking.cs` — criação da sala e preenchimento (inclui os bugs)
11. `Server/Logic/Game/Battles.cs` + `Events.cs` + `Teams.cs`

**NETWORK:** `TCPGateway`, `Connection`, `Messaging`, `Processor`, `MessageManager`, `UDPGateway`, `UDPSocket`, `UDPGameListener`, `HomeGameListener`, `Session(s)`, `MessageFactory`, mensagens `Battle/*` (20559, 23456, 24109, 10555, 14104), `Udp/*` (10177, 24112), `Home/Matchmake*` (14103, 14106, 20405), `Team/*` (14350–24130).

**PLAYER/HOME:** `ClientAvatar` (BattleId/UdpSessionId/TeamIndex/OwnIndex), `ClientHome` (CharacterId, recompensas), `Hero`, `HomeMode`, `PlayerDisplayData`.

**DATA/SUPPORT:** `DataTables(.Types).cs`, `DataTable`, `LogicData`, `Row/Table` (leitor CSV), `CharacterData`, `SkillData`, `ProjectileData`, `AreaEffectData`, `ItemData`, `TileData`, `LocationData`, `GlobalId`, `ByteStreamHelper`, `GameModeUtil`, `GamePlayUtil`, `GameTime`, `LogicGameListener`/`LogicServerListener`, `BitStream`, `ByteStream`, `ChecksumEncoder`, `RC4Encrypter`/`CryptoRC4`, `LogicMath`, `LogicVector2`, `LogicRandom`, **assets**: `csv_logic/*.csv` + `tilemaps.json` + `Settings.json` + `gameplay.json`.

---

## J — PONTOS CRÍTICOS PARA COMPORTAMENTO 1:1

1. **Tick de 50 ms (20 TPS)** via `System.Threading.Timer(1000/20)` e a ordem exata do `ExecuteOneTick` (inputs → killlists → game-over → PreTick → Tick → tick++ → visão).
2. **Encoding do Index**: `PlayerIndex + 16*TeamIndex`; time = `Index/16`; player no time = `Index%16`. Toda a lógica de time (colisão de projétil, área, visão, cofres) depende dessa divisão inteira.
3. **Layout bit-a-bit do VisionUpdate** (C.19) — incluindo hardcoded `VInt(1)` de command count, bits 13/14→15/16 de coordenadas no modo 6, `m_gemGrabCountdown` com 15 bits, HP com 11 vs 13 bits, e `FadeCounter` com valor 10 para o próprio time.
4. **RNG determinístico**: `LogicRandom` com seed **0** e a ordem das chamadas (`GetRandomInt`) afetam spawn de loot boxes e ângulos de itens — para replay 1:1 preserve a ordem de chamadas.
5. **Fórmulas exatas**: velocidade `Speed/20` por tick; delta de projétil `Cos/20000*Speed`; alcance `m_totalDelta > CastingTime*180` (com `castingTime = range/2+1`); dano `+5%*(nível+mult)`; regen `13%/s` após 3 s sem dano; carga de ultimate `UltiChargeMul*dano/UltiChargeDiv` cap 1000; recarga `1000/(RechargeTime/50)` por tick.
6. **Recompensas e condições de fim exatas** (3600/16000 ticks; countdown 17 s GemGrab / 30 s Artifact; 2520 ticks Bounty; `rand.Next(5,8)+1` troféus na vitória; -2 na derrota clampado; 40/rank tokens no BR).
7. **Canal duplo**: visão por UDP **sem criptografia** e com framing próprio; `BattleEndMessage`/mensagens "TCP" por TCP com RC4 — o `UDPGameListener.SendMessage` vs `SendTCPMessage` define o canal.
8. **A troca de GameListener no primeiro pacote UDP** (de `HomeGameListener` para `UDPGameListener`) e o `ChangePlayerSessionId` no re-login.
9. **Bugs comportamentais que definem o "1:1"**: reset de `Matchmaking.Slots` a cada request; `MatchMakingCancelledMessage` nunca enviada; dano não-aplicado quando projétil tem `SpawnAreaEffectObject`; invisibilidade permanente; melee do Primo inexistente; `AddChips` no-op; `UpdatePlayerStatus`/`TileMap.Tick` vazios; buffs de dano sem efeito; sockets UDP nunca liberados; entradas órfãs em `m_playersByObjectGlobalId`; charge/stun/pushback não implementados.
10. **Dependência dos assets**: os CSVs (`characters/skills/projectiles/area_effects/items/tiles/locations`) + `tilemaps.json` + `gameplay.json` são parte da lógica (nomes como `"LootBox"`, `"PoisonBarrel"`, `"LaserBall"`, `"Point"`, `"Money"`, `"BattleRoyaleBuff"`, `"OrbSpawner"`, `"Safe1..4"` são resolvidos por NOME).

---

## O QUE NÃO FOI ENCONTRADO / NÃO PÔDE SER CONFIRMADO NO CÓDIGO

- Estados de sala (WAITING/READY/…): **NÃO ENCONTRADO** (sala nasce pronta).
- Pacote de "sair da batalha"/abandono: **NÃO ENCONTRADO**.
- Espectador durante partida já iniciada por outros meios além de `StartSpectateMessage` (14104): só esse caminho.
- Reconexão transparente: só via novo login (`Avatar.BattleId`); **não há reenvio de estado além de `StartLoadingMessage`** (cliente re-simula pelos VisionUpdates).
- Handshake/cripto UDP (NACL, nonce): **NÃO IMPLEMENTADO** (UDP é plaintext; `UdpConnectionInfoMessage` escreve nonce 0).
- `BattlePlayer.AddUltiCharge`, `Character.TriggerBlink`/`ExecuteBlink`, `Projectile.ExecuteChainBullet` (versão comentada), `m_activeChargeType`, `m_isStunned`, `Skill.HasButton/IsOkToReduceCooldown/MaxCooldown`, `Character.GetNormalWeaponDamage`, `Tile.GetCheckSum`, `TileMap.gameObjectManager`: **código morto/comentado — sem chamadas ativas**.
- Balanceamento por troféus no matchmaking, ping/region, servidores múltiplos, chat na batalha, pins em batalha (`BattlePlayer.UsePin` nunca chamado por handler): **NÃO ENCONTRADO**.
- Persistência imediata de recompensas: acontece no cache em memória; gravação MySQL a cada 30 s (`AccountCache.SaveAll`).
