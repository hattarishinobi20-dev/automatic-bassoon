﻿namespace Supercell.Laser.Logic.Home.Gatcha
{
    using Supercell.Laser.Logic.Avatar;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Titan.DataStream;

    public class GatchaDrop
    {
        public int Count;
        public int rarity;
        public int DataGlobalId;
        public int PinGlobalId;
        public int Type;

        public GatchaDrop(int type, int Rarity)
        {
            Type = type;
            rarity = Rarity;
        }

        public void DoDrop(HomeMode homeMode)
        {
            ClientAvatar avatar = homeMode.Avatar;

            switch (Type)
            {
                case 1: // Unlock a hero
                    CharacterData characterData = DataTables.Get(16).GetDataByGlobalId<CharacterData>(DataGlobalId);
                    if (characterData == null) return;

                    CardData cardData = DataTables.Get(23).GetData<CardData>(characterData.Name + "_unlock");
                    if (cardData == null) return;

                    avatar.UnlockHero(characterData.GetGlobalId(), cardData.GetGlobalId());
                    break;
                case 5: // Add chips
                    avatar.AddChips(Count);
                    break;
                case 6: // Add elexir
                    avatar.AddElexir(Count);
                    break;
                case 7: // Add gold
                    avatar.AddGold(Count);
                    break;
                case 8: // Add Gems (Bonus)
                    avatar.AddDiamonds(Count);
                    break;
            }
        }

        public void Encode(ByteStream stream)
        {
            if (Type != 1)
            {
                stream.WriteVInt(5);
                stream.WriteVInt(6);
            }
            else
            {
                stream.WriteVInt(0);
            }
            stream.WriteVInt(Count);
            if (Type == 1)
            {
                ByteStreamHelper.WriteDataReference(stream, DataGlobalId);
            }
            else
            {
                stream.WriteVInt(0);
            }
        }
    }
}
