# MANIFEST — LÓGICAS RESPONSÁVEIS PELAS BATALHAS ONLINE + GAMEROOMS
### RoyaleBrawl-v1 (client Brawl Stars 1.1714) — extração 1:1 para port/reimplementação

Este pacote espelha **a estrutura original do repositório** (`src/...`) para facilitar
diff/traceabilidade com o código original, e inclui:

```
RoyaleBrawl-batalha-logicas/
├── MANIFEST-LOGICAS.md               ← este arquivo (classificação arquivo a arquivo)
├── ANALISE-BATALHA-GAMEROOMS.md      ← análise profunda 1:1 (fluxos, opcodes, bitstream, fórmulas)
├── database.sql                      ← schema MySQL (accounts / alliances)
├── README.md / LICENSE               ← originais do repo
└── src/
    ├── Supercell.Laser.Titan/        ← biblioteca base (streams/cripto/math) — NETWORK+SUPPORT
    ├── Supercell.Laser.Logic/        ← lógica de jogo (batalha/dados/mensagens) — CORE
    ├── Supercell.Laser.Server/       ← executável (rede/matchmaking/handlers) — GAMEROOM+NETWORK
    ├── Settings.json                 ← RC4/Milestones (lido pelo servidor)
    └── scripti.js                    ← script Frida de debug do client (SUPPORT, não é servidor)
```

> **Por que o pacote contém os 3 projetos inteiros?** O hub de handlers da batalha
> (`MessageManager.cs`) referencia tipos sociais (club/friends/ranking) apenas para
> compilar; a classificação abaixo separa exatamente **o que é lógica de batalha** do
> que é apenas dependência de compilação/execução. Nada foi alterado — código idêntico
> ao commit `a889232`.

---

## LEGENDA DE CATEGORIAS
| Categoria | Significado |
|---|---|
| **CORE** | Essencial para a batalha — sem isto a partida não existe |
| **GAMEROOM** | Criação/gerenciamento/ciclo de vida da sala |
| **NETWORK** | Comunicação, pacotes, criptografia, sessões |
| **PLAYER** | Estado do jogador dentro/fora da partida |
| **GAME** | Regras gerais da partida, balanceamento, dados |
| **SUPPORT** | Utilizado indiretamente (boot, persistência, compilação) |

---

## 1. CORE — o coração da batalha (`src/Supercell.Laser.Logic/Battle/`)

| Arquivo | Classe(s) | Papel na batalha |
|---|---|---|
| `Battle/BattleMode.cs` | `BattleMode`, `DiedEntry` | **A GAMEROOM em si**: tick 20 TPS (`Timer 1000/20`), fila de inputs, spawn/respawn, regras de fim por modo, recompensas (`SendBattleEndToPlayers`), visão por jogador, RNG seed 0 |
| `Battle/Objects/GameObject.cs` | `GameObject` | Base de todo objeto: Position/Z, Index, FadeCounter (bushes), GlobalID, Encode base |
| `Battle/Objects/GameObjectManager.cs` | `GameObjectManager` | Mundo da partida: add/remove queue, `PreTick`/`Tick`, visibilidade por time, **serialização BitStream do VisionUpdate** |
| `Battle/Objects/Character.cs` | `Character` | Entidade viva: movimento (`MoveTo`, `CheckObstacle`), ataque (`ActivateSkill`→`Attack`), dano (`CauseDamage`), regen, buffs/veneno/imunidade, IA (`TickBot`/`TickAI`), pickups, encode completo |
| `Battle/Objects/Projectile.cs` | `Projectile` | Projéteis: voo direto/indireto (parábola), colisão com tiles (destruição de parede por ulti), colisão com personagens, chain bullet, dano percentual, spawn de área/personagem |
| `Battle/Objects/AreaEffect.cs` | `AreaEffect` | Áreas: `Damage`, `Dot`, `Hot` (cura aliada), `BulletExplosion` (radial), destruição de ambiente |
| `Battle/Objects/Item.cs` | `Item` | Itens de chão: gemas/Power Cubes/dinheiro/minas, animação, pickup (4 ticks), `BoxOfMines` |
| `Battle/Structures/BattlePlayer.cs` | `BattlePlayer` | Estado por jogador: índices, carga de ultimate (`ChargeUlti`/`UseUlti`), score, KillList, spawn point, `Create`/`CreateBotInfo` |
| `Battle/Structures/PlayerKillEntry.cs` | `PlayerKillEntry` | Entrada do kill feed (PlayerIndex + BountyStarsEarned) |
| `Battle/Component/Skill.cs` | `Skill` | Munição/recarga (`Charge += 1000/(RechargeTime/50)`), ActiveTime, `ShouldAttackThisTick`, ATTACK_PATTERN_TABLE, encode |
| `Battle/Component/Buff.cs` | `Buff` | Status effects (tipos 1–10; só velocidade tem efeito real) |
| `Battle/Component/Immunity.cs` | `Immunity` | Invulnerabilidade pós-spawn (60 ticks, 100%) |
| `Battle/Component/Poison.cs` | `Poison` | DoT (dano a cada 20 ticks) |
| `Battle/Input/ClientInput.cs` | `ClientInput` | Formato do input (Index, Type, X, Y) decodificado do opcode 10555 |
| `Battle/Level/TileMap.cs` | `TileMap` | Grade do mapa, spawns ('1'/'2'), loot boxes ('4'), poison barrels ('5'), safes ('6'-'9'), conversão lógico↔tile (300) |
| `Battle/Level/Tile.cs` | `Tile` | Tile individual + `TileData` + `Destruct()` |
| `Battle/Level/Rect.cs` | `Rect` | Play area (`IsInPlayArea`) |
| `Battle/Level/Factory/TileMapFactory.cs` | `TileMapFactory` | Carrega `Assets/tilemaps.json` e instancia o mapa por `Location.AllowedMaps` |

## 2. GAMEROOM — criação e ciclo de vida da sala (`src/Supercell.Laser.Server/Logic/Game/`)

| Arquivo | Classe(s) | Papel |
|---|---|---|
| `Game/Battles.cs` | `Battles` | Registro `ConcurrentDictionary<long, BattleMode>` + thread GC (1 s) que remove salas `IsGameOver` |
| `Game/Matchmaking.cs` | `Matchmaking`, `MatchmakingSlot`, `MatchmakingEntry` | **Cria a sala** (`StartGame`): BattleMode novo, sockets UDP por player, times (cap 3, PrefferedTeam de premades), bots até 6/10, `AddGameObjects`, `StartLoadingMessage`, `battle.Start()`; timeout de busca 20 s |
| `Game/Teams.cs` | `Teams` | Lobby premade: `Teams.StartGame(team)` → 24130 + `RequestMatchmake(..., team.Id)` |
| `Game/Events.cs` | `Events` | Gera `EventData` por slot a partir de `gameplay.json` (60 min) — alimenta o matchmaking com LocationId/modo |
| `Logic/HomeGameListener.cs` | `HomeGameListener` | Listener TCP (home) — substituído pelo UDPGameListener no 1º pacote UDP |
| `Logic/ServerListener.cs` | `ServerListener` | Implementa `LogicServerListener` (IsPlayerOnline/GetGameListener/GetHomeMode) — usado por times/streams |

## 3. NETWORK — pacotes, transporte e handlers

| Arquivo | Classe(s) | Papel |
|---|---|---|
| `Server/Networking/TCPGateway.cs` | `TCPGateway` | Accept loop TCP 9339, receive → `Messaging.OnReceive` |
| `Server/Networking/Connection.cs` | `Connection` | Estado por conexão: `UdpSessionId`, `MatchmakeSlot/Entry`, Home/Avatar |
| `Server/Networking/Connections.cs` | `Connections` | GC de conexões mortas (keepalive 30 s) |
| `Server/Networking/Messaging.cs` | `Messaging` | Framing 7 bytes (type/len/version) + RC4 + `MessageFactory` + `Processor` |
| `Server/Networking/Session/Session.cs` / `Sessions.cs` | `Session`, `Sessions` | Sessões por AccountId (reconexão, shutdown) |
| `Server/Networking/UDP/UDPGateway.cs` | `UDPGateway` | Socket UDP 9449 (plaintext), dicionário sessionId→UDPSocket, `CreateSocket`, 1º pacote instala `UDPGameListener` |
| `Server/Networking/UDP/UDPSocket.cs` | `UDPSocket` | Framing UDP (`Long sessionId, Short 0, VInt type, VInt len`) → decodifica 10555 → `Battle.AddClientInput` / `HandleSpectatorInput` |
| `Server/Networking/UDP/Game/UDPGameListener.cs` | `UDPGameListener` | **Canal duplo**: `SendMessage`→UDP (VisionUpdate) e `SendTCPMessage`→TCP (BattleEnd) |
| `Server/Message/Processor.cs` | `Processor` | Filas recv/send (cap 1024, 2 threads) — bombeia `MessageManager` |
| `Server/Message/MessageManager.cs` | `MessageManager` | **Hub de handlers**: login+rejoin de batalha, 14103/14106 matchmaking, 14355 ready→`Teams.StartGame`, 14104/14107 espectate, 10177→24112 |
| `Logic/Message/MessageFactory.cs` | `MessageFactory` | Registro opcode→classe (C→S) |
| `Logic/Message/GameMessage.cs` | `GameMessage` | Base encode/decode + ByteStream |
| `Logic/Message/Battle/StartLoadingMessage.cs` | — | **20559 S→C**: players/OwnIndex/TeamIndex/LocationId/GameMode |
| `Logic/Message/Battle/VisionUpdateMessage.cs` | — | **24109 S→C**: Tick + HandledInputs + bitstream de visão (20 Hz) |
| `Logic/Message/Battle/BattleEndMessage.cs` | — | **23456 S→C**: resultado, recompensas, milestones |
| `Logic/Message/Battle/ClientInputMessage.cs` | — | **10555 C→S**: fila de `ClientInput` (via UDP) |
| `Logic/Message/Battle/StartSpectateMessage.cs` | — | **14104 C→S**: espectatar por AccountId |
| `Logic/Message/Udp/ClientInfoMessage.cs` / `UdpConnectionInfoMessage.cs` | — | **10177 C→S / 24112 S→C**: entrega sessionId UDP + host/port |
| `Logic/Message/Home/MatchmakeRequestMessage.cs` | — | **14103 C→S**: SelectedCard + EventSlot |
| `Logic/Message/Home/CancelMatchmakingMessage.cs` | — | **14106 C→S** |
| `Logic/Message/Home/MatchMakingStatusMessage.cs` | — | **20405 S→C**: progresso da fila |
| `Logic/Message/Home/MatchMakingCancelledMessage.cs` | — | **20406** (classe existe, **nunca enviada**) |
| `Logic/Message/Home/GoHomeMessage.cs`, `GoHomeFromOfflinePractiseMessage.cs`, `StopSpectateMessage.cs`, `OutOfSyncMessage.cs`, `EndClientTurnMessage.cs`, `ChronosEventSeenMessage.cs`, `PlayerStatusMessage.cs`, `OwnHomeDataMessage.cs` | — | fluxo home/rejoin/espectate |
| `Logic/Message/Team/*.cs` (14 arquivos) | — | Lobby de time (14350–14479 / 24124–24131) que deságua no matchmaking |
| `Logic/Message/Account/*.cs` (Auth, KeepAlive, ClientCapabilities, Disconnected, ShutdownStarted) | — | login (com rejoin de batalha via `Avatar.BattleId`), keepalive, kick de sessão duplicada |
| `Logic/Listener/LogicGameListener.cs` / `LogicServerListener.cs` | — | Contratos de envio/consulta (Logic ↔ Server) |
| `Titan/DataStream/BitStream.cs` | `BitStream` | Escrita bit-a-bit do VisionUpdate (WritePositiveInt etc.) |
| `Titan/DataStream/ByteStream.cs` | `ByteStream` | Leitura/escrita de todas as mensagens (VInt, Long, String...) |
| `Titan/DataStream/ChecksumEncoder.cs` | `ChecksumEncoder` | Base do ByteStream com checksum |
| `Titan/Cryptography/RC4Encrypter.cs` + `Titan/Library/CryptoRC4.cs` | — | RC4 TCP (chave hardcoded + nonce) |

## 4. PLAYER — estado do jogador

| Arquivo | Classe(s) | Papel |
|---|---|---|
| `Logic/Avatar/ClientAvatar.cs` | `ClientAvatar` | `BattleId`, `UdpSessionId`, `TeamIndex`, `OwnIndex`, Heroes, troféus — ponte login↔batalha |
| `Logic/Avatar/Structures/PlayerDisplayData.cs` | `PlayerDisplayData` | Nome/thumbnail exibidos na sala |
| `Logic/Home/ClientHome.cs` | `ClientHome` | `CharacterId` (brawler selecionado), recompensas acumuladas, encode home |
| `Logic/Home/HomeMode.cs` | `HomeMode` | Carrega estado pós-login, `ClientTurnReceived` (comandos 14102) |
| `Logic/Home/Structures/Hero.cs` | `Hero` | Troféus por brawler (`AddTrophies` — aplicado no fim da batalha) |
| `Logic/Home/Items/EventData.cs` | `EventData` | Slot/LocationId/EndTime exibidos no home (origem do matchmaking) |
| `Logic/Home/Items/MilestonesArray.cs` | `Milestones` | Serializado dentro do `BattleEndMessage` |
| `Logic/Team/TeamEntry.cs` / `TeamMember.cs` / `TeamInviteEntry.cs` / `TeamJoinRequest.cs` / `Team/Stream/*.cs` | — | Lobby premade (vira `PlayerTeamId`/`PrefferedTeam` no `StartGame`) |

## 5. GAME — regras, balanceamento e dados

| Arquivo | Classe(s) | Papel |
|---|---|---|
| `Logic/Util/GameModeUtil.cs` | — | Variação por nome de modo, ticks da partida (3600/16000), respawn (3/1/5 s), `HasTwoTeams` |
| `Logic/Util/GamePlayUtil.cs` | — | Players por modo (10 BR / 6 demais) |
| `Logic/Time/GameTime.cs` | `GameTime` | Contador de tick da batalha |
| `Logic/Data/DataTables.cs` + `DataTables.Types.cs` | `DataTables`, `DataType` | Carregamento dos CSVs (tabelas 6,8,15,16,17,18,20,23,27,28,29) |
| `Logic/Data/Helper/{DataTable,LogicData,GlobalId}.cs` | — | Acesso por nome/globalId; `GlobalId = classId*1000000+instanceId` |
| `Logic/Data/Reader/{Row,Table,Column,Gamefiles}.cs` | — | Parser CSV por reflexão (alimenta as classes *Data) |
| `Logic/Data/CharacterData.cs` | — | HP, Speed, skills, UltiChargeMul/Div, Type ("Hero", "LootBox", "Pvp_Base"...) |
| `Logic/Data/SkillData.cs` | — | Dano, Spread, NumBullets, RechargeTime, ActiveTime, BehaviorType, Projectile, SummonedCharacter, AreaEffectObject(2) |
| `Logic/Data/ProjectileData.cs` | — | Speed, Indirect, Gravity, Pierces, ChainBullet, SpawnAreaEffectObject(2), PoisonDamagePercent, FreezeStrength |
| `Logic/Data/AreaEffectData.cs` | — | Type (Damage/Dot/Hot/BulletExplosion), Radius, TimeMs, DestroysEnvironment |
| `Logic/Data/ItemData.cs` | — | CanBePickedUp etc. (Point, Money, BattleRoyaleBuff, OrbSpawner, Mine...) |
| `Logic/Data/TileData.cs` | — | BlocksMovement/BlocksProjectiles/IsDestructible/HidesHero/RespawnSeconds |
| `Logic/Data/LocationData.cs` | — | GameMode + AllowedMaps (chave do tilemaps.json) |
| `Logic/Data/CardData.cs` / `PlayerThumbnailData.cs` / `SkinData.cs` | — | Referenciados por home/comandos/herói |
| `Logic/Helper/ByteStreamHelper.cs` | — | WriteDataReference/WriteObjectRunning (usados no StartLoading e VisionUpdate) |
| `Assets/csv_logic/*.csv` | — | **Balanceamento real**: characters, skills, projectiles, area_effects, items, tiles, locations, cards, player_thumbnails, alliance_badges, skins (todos exigidos por `DataTables.Load`) |
| `Assets/tilemaps.json` (+ `Assets/csv_logic/tilemaps.json`) | — | **Mapas** (grade ASCII por nome `AllowedMaps`) |
| `Assets/fingerprint.json` | — | Lido no boot (`Fingerprint.Load`) |

## 6. SUPPORT — indireto, mas necessário

| Arquivo | Papel |
|---|---|
| `Titan/Math/{LogicMath,LogicVector2,LogicRandom,LogicLong}.cs` | Trigonomometria/ângulos (Cos/Sin escala 20000), distâncias, **RNG determinístico da batalha**, LogicLong |
| `Titan/Debug/Debugger.cs` | Asserts/warnings usados na batalha |
| `Titan/Json/LogicJSON*.cs` | Parser de `tilemaps.json` / `gameplay.json` / `Settings.json` |
| `Titan/Util/StringUtil.cs` | Utilitários de string |
| `Logic/GameVersion.cs` | 1 / 1714 (handshake) |
| `Logic/Command/**` (Command, CommandManager, Avatar/*, Home/*) | Decodificados no 14102 (`EndClientTurnMessage`) — comandos 500/506/507/1000 |
| `Logic/Message/Club/**`, `Friends/**`, `Ranking/**`, `Logic/Club/**`, `Friends/**`, `Stream/**` | **Sem papel na batalha** — presentes porque `MessageManager`/login os referenciam (compilação + fluxo home) |
| `Logic/Message/Notification/**`, `Logic/Home/Gatcha/**`, `Logic/Data` restantes (`GlobalData`, `ThemeData`, etc.) | Fluxo home (fora da batalha) |
| `Server/Program.cs` + `Resources.cs` | Boot (InitDatabase/InitLogic/InitNetwork) — sobe Battles/Matchmaking/Teams/Events e gateways |
| `Server/Settings/{Configuration,Fingerprint}.cs` | config.json / fingerprint |
| `Server/Database/**` (Accounts, Alliances, Caches, Models/Account) | Persistência MySQL — troféus/recompensas da batalha são salvos pelo `AccountCache` (30 s) |
| `Server/Logic/Game/Leaderboards.cs` | Ranking (home) |
| `Server/Handler/{CmdHandler,ExitHandler}.cs` | Console admin / shutdown limpo |
| `Server/config.json` / `gameplay.json`, `Settings.json`, `database.sql` | Configuração de rede/eventos/RC4 e schema |
| `src/scripti.js` | Script Frida do cliente (ferramenta de debug — não faz parte do servidor) |

---

## CHECKLIST MÍNIMO PARA PORTAR A BATALHA (extraído da seção I da análise)

Se o objetivo é reimplementar em outro servidor, os arquivos **obrigatórios** são, nesta ordem:

1. `Battle/**` inteiro (19 arquivos CORE) + `Util/GameModeUtil.cs` + `Util/GamePlayUtil.cs` + `Time/GameTime.cs`
2. `Server/Logic/Game/{Battles,Matchmaking,Teams,Events}.cs`
3. `Networking/**` do Server (TCP+UDP+Session) + `Message/{MessageManager,Processor}.cs`
4. Mensagens: `Battle/*`, `Udp/*`, `Home/Matchmake*+OutOfSync+GoHome*+EndClientTurn+OwnHomeData`, `Team/*`, `Account/Auth+KeepAlive+Disconnected`
5. `Data/**` (DataTables+Reader+`CharacterData/SkillData/ProjectileData/AreaEffectData/ItemData/TileData/LocationData`) + `Helper/{ByteStreamHelper,GlobalId}`
6. `Titan` completo (BitStream/ByteStream/ChecksumEncoder/RC4/Math/JSON)
7. `Player`: `ClientAvatar`, `ClientHome`, `HomeMode`, `Hero`, `EventData`, `BattlePlayer` deps
8. **Assets**: `csv_logic/*.csv` + `tilemaps.json` + `Settings.json` + `gameplay.json` + `fingerprint.json`

## COMO COMPILAR/RODAR (do README original)
1. `dotnet build src/Supercell.Laser.Server/Supercell.Laser.Server.csproj` (requer .NET 6.0)
2. Importar `database.sql` no MySQL; ajustar `src/Supercell.Laser.Server/config.json` (udp_host + banco)
3. `dotnet Supercell.Laser.Server.dll` — TCP 9339 / UDP 9449

## AVISOS 1:1 (bugs comportamentais que definem a identidade do servidor)
- `Matchmaking.RequestMatchmake` **reseta `Slots`** a cada chamada (filas solo não acumulam entre requests)
- `MatchMakingCancelledMessage` (20406) nunca é enviada
- Dano do projétil **não aplicado** quando ele possui `SpawnAreaEffectObject` (o dano vem só da área)
- Invisibilidade nunca expira; melee (Primo) não implementado; Charge/Stun/Pushback não implementados
- `ClientAvatar.AddChips` é no-op; `UpdatePlayerStatus`/`TileMap.Tick` são vazios
- Entradas de `m_playersByObjectGlobalId` ficam órfãs no respawn; `UDPGateway.Sockets` nunca é limpo
- RNG da batalha com **seed fixa 0** (ordem de chamadas afeta loot boxes/ângulos de itens)

Detalhes completos de fluxo, opcodes e layout bit-a-bit do VisionUpdate: ver `ANALISE-BATALHA-GAMEROOMS.md`.
