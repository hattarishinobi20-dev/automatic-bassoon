# Análise 1:1 — batalhas online e GameRoom/Teams

**Repositório:** `Super-brawl-team/RoyaleBrawl-v1`  
**Commit analisado:** `a889232c0fb3f773757514b22ca7054ad6f8f9c4` (`2026-01-26`)  
**Escopo:** fluxo completo de eventos, matchmaking, salas/equipes, criação da batalha, TCP/UDP, inputs, simulação a 20 TPS, objetos, modos, espectadores, encerramento, recompensas e persistência.

> Neste código não existe uma classe chamada `GameRoom`. A “sala online” é representada por `TeamEntry`, administrada por `Teams`, e conectada ao matchmaking por `TeamId`/`PlayerTeamId`.

---

## 1. Resumo executivo

A arquitetura é **server-authoritative**: o cliente envia comandos de movimento/ataque via UDP e o servidor simula a partida em `BattleMode`, enviando um snapshot (`VisionUpdateMessage`) a cada tick. O tick nominal é de **20 TPS** (50 ms).

Fluxo principal:

```text
TCP login/home
  -> eventos disponíveis
  -> solo: MatchmakeRequestMessage
     ou sala: TeamCreate/Invite/Ready -> Teams.StartGame
  -> MatchmakingSlot
  -> BattleMode + BattlePlayer + bots + UDPSocket por humano
  -> StartLoadingMessage via TCP
  -> ClientInfoMessage via TCP
  -> UdpConnectionInfoMessage via TCP
  -> primeiro datagrama UDP vincula endpoint e instala UDPGameListener
  -> ClientInputMessage via UDP
  -> fila de inputs do BattleMode
  -> simulação a 20 TPS
  -> VisionUpdateMessage via UDP
  -> BattleEndMessage via TCP
  -> cache da conta salva no MySQL a cada 30 segundos
```

### Estado real de implementação

- Há PvP funcional em nível básico: movimento, projéteis, colisão, dano, cura, veneno, itens, respawn, bots e snapshots.
- As salas funcionam em memória: criar, convidar, aceitar, sair, escolher personagem/evento, chat e ready.
- Muitos mecanismos existem apenas parcialmente ou estão codificados como placeholders.
- O matchmaking do commit analisado possui um erro crítico que pode descartar filas a cada nova busca.
- A concorrência não é segura: timers, UDP e threads de rede acessam `Queue`, `Dictionary` e estado de batalha sem locks.
- O UDP não autentica o endpoint além de um ID sequencial de sessão.
- Brawl Ball não possui regra de gol/vitória; termina em empate por tempo.
- Charges, melee do Primo, pushback, status de jogador e atualização de mapa estão incompletos.

---

# 2. Inicialização global

## `src/Supercell.Laser.Server/Resources.cs`

`InitLogic()` inicializa, nesta ordem:

1. fingerprint;
2. tabelas CSV;
3. eventos;
4. sessões;
5. leaderboards;
6. registro de batalhas;
7. matchmaking;
8. salas (`Teams`).

`InitNetwork()` inicia o gateway UDP e o TCP.

### Problema de ordem/race

`Events.Init()` cria um `Timer` com vencimento inicial `0`, e a geração de eventos ocorre no callback. Logo depois, `Matchmaking.Init()` chama `Events.GetEvents()`. Não existe garantia de que o timer já tenha preenchido `Slots`. Assim, o matchmaking pode iniciar sem slots.

Também há uma janela em que as threads de rede podem observar estruturas globais sem proteção.

---

# 3. Eventos e escolha de modos

## `src/Supercell.Laser.Server/Logic/Game/Events.cs`

- Lê `gameplay.json`.
- Para cada slot, escolhe aleatoriamente uma `LocationData` cujo `GameMode` esteja permitido.
- Exclui apenas a localização `Tutorial`.
- Atualiza os eventos a cada 60 minutos.
- Cada evento carrega `Slot`, `LocationId` e `EndTime`.

## `src/Supercell.Laser.Server/gameplay.json`

Configuração do commit:

| Slot | Modos permitidos |
|---:|---|
| 1 | BattleRoyale |
| 2 | BattleRoyale |
| 3 | BountyHunter |
| 4 | CoinRush |

Embora o motor conheça Heist/AttackDefend, Artifact e LaserBall, eles não aparecem na rotação configurada.

## `GameModeUtil.cs`

Mapeamento de variações:

| Variação | Nome CSV | Interpretação |
|---:|---|---|
| 0 | `CoinRush` | Gem Grab |
| 1 | `Campaign` | campanha/dev |
| 2 | `AttackDefend` | Heist |
| 3 | `BountyHunter` | Bounty |
| 4 | `Artifact` | segurar artefato |
| 5 | `LaserBall` | Brawl Ball |
| 6 | `BattleRoyale` | Showdown solo |

`HasTwoTeams()` retorna falso somente para a variação 6. `GamePlayUtil.GetPlayerCountWithGameModeVariation()` exige 10 jogadores em Showdown e 6 nos demais modos.

---

# 4. Matchmaking solo

## Entrada TCP

### `Message/MessageFactory.cs`

Registra:

- `14103` → `MatchmakeRequestMessage`;
- `14106` → `CancelMatchmakingMessage`;
- `10177` → `ClientInfoMessage`;
- `10555` → `ClientInputMessage`.

O input 10555 recebido por TCP é deliberadamente ignorado em `MessageManager`; a batalha usa esse pacote somente no UDP.

### `Message/Home/MatchmakeRequestMessage.cs`

Decodifica:

- personagem selecionado (`SelectedCard`);
- slot do evento (`EventSlot`).

### `Server/Message/MessageManager.cs`

`MatchmakeRequestReceived()`:

1. grava o personagem em `Home.CharacterId`;
2. rejeita personagem marcado como desabilitado;
3. chama `Matchmaking.RequestMatchmake(connection, slot)`.

Não valida explicitamente se:

- o jogador já está em fila;
- já está em batalha;
- o slot está dentro dos limites;
- o personagem pertence à conta;
- a mensagem é permitida no estado atual da sessão.

## Gerenciador

### `Server/Logic/Game/Matchmaking.cs`

`Init()` cria um `MatchmakingSlot` para cada evento e inicia uma thread que chama `slot.Update()` a cada 250 ms.

Cada slot contém:

- `RequestQueue`: entradas a adicionar;
- `RemoveQueue`: entradas a remover;
- `Queue`: lista efetiva;
- `PlayersRequired`: 6 ou 10;
- evento/localização;
- cronômetro de 20 segundos.

`Update()`:

1. marca conexões fechadas para remoção;
2. processa remoções;
3. processa novas entradas;
4. se houver jogadores suficientes, cria partidas completas;
5. após 20 segundos, inicia com os humanos disponíveis e completa com bots;
6. envia `MatchMakingStatusMessage` a cada ciclo.

### Defeito crítico: filas são apagadas

Em `RequestMatchmake()` (linhas 58–96), a linha 62 executa:

```csharp
Slots = new Dictionary<int, MatchmakingSlot>();
```

Isso recria **todo o dicionário global em cada solicitação**. Consequências:

- jogadores em filas anteriores são perdidos;
- o segundo jogador pode não encontrar o primeiro;
- a thread `Update()` pode estar enumerando o dicionário antigo enquanto a referência global muda;
- cancelamento pode não encontrar a fila original;
- cada pedido tende a criar somente o slot solicitado.

Há outro erro lógico nas linhas 65–73:

```csharp
if (events.Length <= 0)
{
    foreach (EventData e in events)
```

O laço só é executado quando o array está vazio, portanto nunca adiciona nada.

Na ausência do slot, usa `Events.GetEvents()[slot - 1]`. Isso supõe que:

- os slots são contíguos e começam em 1;
- a ordem de `Dictionary.Values` coincide com o número do slot;
- o índice é válido.

Nenhuma dessas condições é garantida como contrato robusto.

### Concorrência insegura

`RequestQueue`, `RemoveQueue`, `Queue` e `Slots` são coleções comuns. Chamadas vindas das threads TCP concorrem com a thread de matchmaking sem `lock`, `ConcurrentQueue` ou canal. Podem ocorrer:

- corrupção lógica;
- `InvalidOperationException` durante enumeração;
- perda/duplicação de entrada;
- cancelamento recursivo inconsistente para equipes.

### Cancelamento

`CancelMatchmake()` remove a entrada e, se ela pertence a uma sala, percorre os membros, zera ready e cancela todos recursivamente.

Riscos:

- acessa `connection.MatchmakingEntry.PlayerTeamId` sem garantir que `MatchmakingEntry` existe;
- presume que `Teams.Get()` e `Sessions.GetSession()` não retornam nulo;
- altera `PlayerTeamId` antes da recursão para evitar recancelamento coletivo, mas o estado parcial pode ficar inconsistente em exceção;
- envia `MatchMakingStatusMessage`, não `MatchMakingCancelledMessage`.

---

# 5. GameRoom: salas online implementadas como Team

## Modelo

### `Logic/Team/TeamEntry.cs`

É a sala em memória. Contém:

- `Id` incremental;
- `Type`;
- `LocationId` e `EventSlot`;
- `Members`;
- `Invites`;
- `JoinRequests` (não implementado);
- `DisabledBots` (não utilizado no início da batalha);
- stream de chat.

Capacidade enviada ao cliente: **3**, mas não há validação server-side desse limite.

`TeamUpdated()` transmite um `TeamMessage` a todos os membros online. `AddStreamEntry()` transmite atualizações de chat.

### `TeamMember.cs`

Mantém conta, brawler, skin, troféus, estado e ready. O nível codificado é sempre zero e o campo `HeroLevel` não é usado no encoder.

### `TeamInviteEntry.cs`

Representa convite. `Id` é usado como ID do convidado; `InviterId` guarda quem convidou.

### `TeamJoinRequest.cs`

`Encode()` lança `NotImplementedException`. Não há fluxo funcional de pedido para entrar.

## Registro das salas

### `Server/Logic/Game/Teams.cs`

- `Entries`: `Dictionary<long, TeamEntry>` global;
- IDs incrementais em memória;
- criar, obter e remover;
- `StartGame()` envia `TeamGameStartingMessage` e coloca cada membro no matchmaking com o mesmo `team.Id`.

Não há persistência das salas. `ClientAvatar.TeamId` é `JsonIgnore`. Reiniciar o servidor apaga todas as salas.

`Entries` também não é thread-safe.

## Criação

### `MessageManager.TeamCreateReceived()`

1. cria `TeamEntry`;
2. copia `TeamType`;
3. escolhe a localização do primeiro evento da lista, ignorando `EventSlot` recebido pela mensagem;
4. cria o dono como membro;
5. grava `Avatar.TeamId`;
6. envia `TeamMessage`.

Faltam verificações para impedir que alguém:

- crie outra sala enquanto já está em uma;
- crie múltiplas salas rapidamente;
- use tipo inválido.

## Convite e aceite

### `TeamInviteReceived()`

- carrega a conta alvo;
- adiciona convite na sala;
- atualiza a sala;
- se o alvo está online, envia `TeamInvitationMessage`.

Não verifica:

- se o remetente é dono;
- se o alvo já está em sala;
- se a sala está cheia;
- convite duplicado;
- auto-convite;
- bloqueio/mute.

### `TeamInvitationResponseReceived()`

- procura a sala e convite pelo ID da conta;
- remove o convite;
- ao aceitar, cria membro e muda `Avatar.TeamId`;
- transmite atualização.

Também não valida capacidade, sala anterior ou estado da batalha.

## Ready e início

`TeamSetMemberReadyReceived()` altera `IsReady`; se todos estão prontos, chama `Teams.StartGame()`.

Problemas:

- qualquer conjunto de membros — inclusive sala com apenas uma pessoa — pode iniciar;
- não há trava “partida iniciando”; mensagens ready repetidas podem iniciar matchmaking mais de uma vez;
- qualquer membro pode alterar evento/localização, pois não há checagem de owner;
- `IsEveryoneReady()` retorna verdadeiro para lista vazia, embora normalmente o método não seja chamado após esvaziar;
- `Teams.StartGame()` presume sessão online para todos e acessa `.Connection` sem null check.

## Preservação do grupo no matchmaking

Cada entrada recebe `PlayerTeamId = team.Id`. Em `StartGame()`:

1. entradas de grupos são agrupadas por ID;
2. cada grupo recebe `PrefferedTeam = i`;
3. os jogadores restantes são anexados;
4. o time padrão é `i % 2`;
5. se o time já tem 3 jogadores, troca para o outro.

Falhas:

- se houver três ou mais IDs de grupos, `PrefferedTeam` pode virar 2, 3 etc., embora a batalha espere times 0/1;
- não há algoritmo de balanceamento por troféus;
- não há separação garantida entre grupos adversários de tamanho incompatível;
- o método modifica a lista `entries` recebida;
- membros do mesmo grupo são preservados em condições normais, mas a regra de capacidade pode quebrar a composição se a sala exceder 3 membros.

## Saída e desconexão

`TeamLeaveReceived()` remove o membro e apaga a sala somente se ficar vazia. Não transfere propriedade se o dono sair.

`Sessions.Remove()` apenas muda `member.State = 0`; não remove o membro. Isso permite reconexão à sala enquanto o processo continua ativo, mas deixa salas/membros órfãos indefinidamente.

## Chat

- `TeamChatMessage` cria `ChatStreamEntry`.
- `TeamPremadeChatMessage` cria `QuickChatStreamEntry`.
- `TeamEntry.AddStreamEntry()` distribui para membros online.

Não há limite de texto, rate limit, moderação ou tamanho máximo do histórico. `StreamUpdated()` está vazio.

---

# 6. Criação da batalha

## `MatchmakingSlot.StartGame()`

1. cria `BattleMode(EventData.LocationId)`;
2. registra em `Battles` e atribui ID;
3. organiza humanos por time;
4. cria um `UDPSocket` por humano;
5. cria `BattlePlayer` para humanos;
6. preenche vagas com bots;
7. chama `battle.AddGameObjects()`;
8. envia `StartLoadingMessage` por TCP;
9. inicia o timer da batalha.

### Bots

Lista permitida: personagens instance IDs 0–16. Em modos 3v3 tenta evitar brawler duplicado no mesmo time. Em Showdown não há essa restrição.

`BattlePlayer.CreateBotInfo()` usa conta artificial `100000 + playerIndex`, `SessionId = -1` e `Bot = true`.

### Nível e skin

`BattlePlayer.Create()` não copia o power level do herói para `HeroPowerLevel`; o valor padrão permanece 0. Portanto `Character.SetHeroLevel()` inicia humanos no nível zero para a simulação, independentemente do progresso real.

`SkinId` é fixado em zero e `BattlePlayer.Encode()` escreve referência de skin nula.

---

# 7. Registro e ciclo de vida das batalhas

## `Server/Logic/Game/Battles.cs`

Usa `ConcurrentDictionary<long, BattleMode>`. IDs são incrementais. Uma thread, a cada segundo, remove batalhas com `IsGameOver`.

Pontos positivos:

- o registro principal é concorrente;
- remoção é desacoplada do tick.

Problemas:

- `m_battleIdCounter` não usa `Interlocked`;
- remover a batalha do registro não encerra/remover os `UDPSocket` associados;
- sockets ainda referenciam a batalha, impedindo coleta de memória;
- não existe método de shutdown/dispose completo.

## `BattleMode.Start()`

Cria `System.Threading.Timer` com período de 50 ms. Cada callback executa `ExecuteOneTick()`.

### Risco de reentrância

`Timer` não garante que um callback lento termine antes do próximo. Não há lock, flag de execução ou loop monotônico. Dois ticks podem se sobrepor e modificar as mesmas filas/objetos simultaneamente.

---

# 8. Transporte TCP e UDP

## TCP

TCP cuida de:

- autenticação/home;
- matchmaking e sala;
- `StartLoadingMessage`;
- dados de conexão UDP;
- `BattleEndMessage`;
- reconexão e spectate.

Arquivos centrais:

- `Networking/TCPGateway.cs`;
- `Networking/Connection.cs`;
- `Networking/Messaging.cs`;
- `Message/Processor.cs`;
- `Message/MessageManager.cs`.

## UDP

### `Networking/UDP/UDPGateway.cs`

- escuta em `0.0.0.0:<udp_port>`;
- lê `sessionId` de 8 bytes e um short;
- procura `UDPSocket` pelo ID;
- no primeiro pacote, fixa o endpoint remoto;
- instala `UDPGameListener` no `BattlePlayer`;
- encaminha o payload.

### `UDPSocket.cs`

Formato de saída:

```text
long sessionId
short 0
VInt messageType
VInt payloadLength
payload
```

`ProcessReceive()` abre um `Task.Run` por datagrama, decodifica uma mensagem e aceita apenas tipo `10555` como input de jogo.

### Problemas críticos do UDP

1. **Sequestro de sessão:** IDs são sequenciais e o primeiro datagrama que chega fixa o endpoint. Não há nonce, MAC, cookie ou validação pelo endereço TCP. Um atacante que adivinhar o ID pode tomar a sessão antes do cliente legítimo.
2. **Replay/ordenação:** há índice por input, mas não existe proteção criptográfica, janela de replay ou ordenação por pacote.
3. **Amplificação de tasks:** um `Task.Run` por datagrama permite exaustão de thread pool/memória.
4. **Comprimento insuficientemente validado:** o tamanho vem do pacote; a leitura possui limite 2000, mas o datagrama máximo lido é 1500 e não há validação explícita do frame antes das leituras.
5. **Coleção insegura:** `Sockets` é `Dictionary` comum, acessado pela thread UDP e por threads TCP que chamam `CreateSocket()`.
6. **Vazamento:** sockets nunca são removidos.
7. **Sem timeout UDP:** endpoint/sessão não expira.
8. **Exceções engolidas:** vários `catch` vazios ocultam falhas operacionais.

## Handshake UDP

Após `StartLoading`, o cliente envia `ClientInfoMessage` via TCP. O servidor responde `UdpConnectionInfoMessage` com host, porta e `SessionId`.

O “nonce” codificado é sempre zero. A segurança depende apenas do session ID incremental.

---

# 9. Reconexão e espectador

## Reconexão

No login, se `Avatar.BattleId > 0` e a batalha ainda existe:

1. envia novo `StartLoadingMessage`;
2. cria novo socket UDP;
3. troca o ID antigo pelo novo em `BattleMode.ChangePlayerSessionId()`;
4. atualiza `Avatar.UdpSessionId`.

Limitações:

- `BattleId`, `UdpSessionId`, time e índice são `JsonIgnore`; sobrevivem apenas enquanto a mesma instância de conta está no cache/processo;
- reiniciar o servidor perde a batalha;
- o socket antigo não é removido;
- não há restauração de inputs pendentes;
- personagem continua parado/ativo sem política explícita de desconexão.

## Espectador

`StartSpectateReceived()`:

- carrega a conta alvo;
- usa `avatar.BattleId` para localizar batalha;
- cria socket UDP marcado como espectador;
- adiciona listener ao dicionário de espectadores;
- envia loading e dados UDP.

Inputs do espectador apenas atualizam `HandledInputs`.

Falhas:

- `StartLoadingMessage.SpectateMode` é preenchido, mas **não é codificado** por `StartLoadingMessage.Encode()`;
- `VisionUpdateMessage.Viewers` é preenchido, mas **não é codificado**;
- sem autorização/privacidade para assistir;
- sem limite de espectadores;
- parar de assistir remove da batalha, mas não remove `UDPSocket` global;
- desconexão abrupta não chama necessariamente `RemoveSpectator()`.

---

# 10. Estrutura de `BattleMode`

## Estado principal

`BattleMode.cs` mantém:

- localização e variação de modo;
- timer/tick e RNG;
- jogadores e índices por sessão/objeto;
- espectadores;
- fila de inputs;
- mapa e área jogável;
- `GameObjectManager`;
- fila de mortos/respawn;
- contagem de vivos;
- placar por jogador;
- vencedor e countdown de objetivo.

## Tick completo

`ExecuteOneTick()` faz:

1. drena inputs;
2. limpa `KillList` de todos os jogadores;
3. calcula fim;
4. se terminou, descarta timer, envia resultado e marca `IsGameOver`;
5. executa `GameObjectManager.PreTick()`;
6. executa objetos/mapa/respawn;
7. incrementa tick;
8. envia visão.

Mesmo depois de detectar o fim, o método ainda executa o restante do tick e envia visão.

Em exceção, descarta o timer e marca game over, mas não envia resultado aos jogadores.

## Inputs

`ClientInput` decodifica apenas:

- `Index`;
- `Type`;
- `X`, `Y`.

Os campos `AutoAttack` e `AutoAttackTarget` existem, mas nunca são decodificados.

Tipos:

- `100`: movimento;
- `107`: marca uso de ultimate visualmente;
- `108`: desmarca;
- `0..99`: índice de uma linha da tabela de skills; se corresponder à arma ou ultimate do personagem, ativa a skill.

### Falhas de validação

- coordenadas não têm rate limit nem validação de velocidade no input;
- movimento rejeita destino fora da área, mas ataque aceita vetores arbitrários;
- input de ultimate chama `player.UseUlti()` sem verificar `player.HasUlti()` no caminho ativo;
- os casos antigos que verificavam `HasUlti()` estão comentados;
- não valida quantidade de inputs por mensagem;
- fila `m_inputQueue` não é thread-safe; UDP adiciona enquanto o tick remove;
- `LastHandledInput` rejeita índices antigos, mas um índice enorme pode bloquear inputs legítimos futuros;
- não existe limite de crescimento da fila.

---

# 11. Objetos da simulação

## `GameObject.cs`

Base de personagem, projétil, efeito e item. Mantém:

- DataId;
- ID global de runtime;
- posição X/Y/Z;
- índice lógico que incorpora jogador e time;
- fade/visibilidade.

Codifica posições com larguras diferentes para Showdown e modos normais.

## `GameObjectManager.cs`

Mantém:

- lista ativa;
- fila de adição;
- fila de remoção;
- contador de IDs;
- referência à batalha.

`PreTick()`:

- agenda objetos destruídos;
- chama `PreTick()` dos restantes;
- move filas para a lista principal.

`Tick()` chama `Tick()` em todos os objetos.

### Snapshot/visão

`Encode()` inclui:

- ID do objeto próprio;
- countdown;
- limites do mapa;
- tiles destruídos;
- ultimate de jogadores;
- estado específico do modo;
- placares e kills;
- catálogo e estado dos objetos visíveis.

Visibilidade é simplificada: objeto aparece se `FadeCounter > 0` ou se pertence ao mesmo time. Não há visão por distância/fog real.

### Problemas

- todas as buscas/colisões são lineares;
- um snapshot completo é reconstruído para cada jogador em cada tick;
- `Parallel.ForEach` codifica jogadores em paralelo usando o mesmo estado mutável;
- `m_tileMap` no manager só é atribuído dentro de `Encode()`, mas `AreaEffect` usa esse campo para destruir cenário; antes do primeiro encode ele pode ser nulo;
- filas e lista não têm sincronização;
- o ID de objeto cresce sem reciclagem.

---

# 12. Personagens, movimento, skills e bots

## `Character.cs`

Responsável por:

- HP e HP máximo;
- movimento;
- armas e ultimate;
- buffs/imunidade/veneno;
- IA;
- regeneração;
- dano/morte;
- itens e placar;
- serialização visual.

## Movimento

`MoveTo()` define destino e ângulo. `HandleMoveAndAttack()` move por eixo usando `CharacterData.Speed / 20`, verifica obstáculos e limites.

### Bug: buffs de velocidade não têm efeito

`MoveTo()` calcula `v46 = Speed + buffs`, mas não usa `v46`. O movimento real volta a usar `CharacterData.Speed / 20`. Portanto slow/speed buff não altera a velocidade, confirmando o TODO do README.

A movimentação diagonal soma deslocamentos independentes em X e Y e pode produzir velocidade maior na diagonal.

## Skills

### `Component/Skill.cs`

- carga local da arma;
- recarga;
- duração ativa;
- cadência;
- direção X/Y;
- padrão de spread.

Problemas:

- propriedades de dados podem causar divisão por zero (`RechargeTime / 50` ou `MsBetweenAttacks / 50`);
- `Targeted` é lido, mas sua lógica está vazia;
- cooldown e várias propriedades não são efetivamente aplicados;
- arma e carga de ultimate usam dois modelos separados (`Skill.Charge` e `BattlePlayer.UltiCharge`), com sincronização incompleta.

## Ataque

`Character.ActivateSkill()` seleciona weapon/ultimate, trata Blink, ativa a skill e pode criar área de efeito.

`HandleMoveAndAttack()` implementa:

- Blink;
- Invisibility;
- Attack com projétil;
- placeholder de Charge.

Ataque melee quando `Projectile == ""` está comentado. Por isso personagens como Primo não causam dano corretamente.

`Attack()` cria os projéteis, aplica escala de dano por nível/cubos e usa spread/padrão rápido.

## Dano e morte

`CauseDamage()`:

- aplica imunidade percentual;
- limita HP;
- bloqueia regeneração;
- grava indicador visual;
- carrega ultimate do atacante;
- acumula dano/kills;
- chama `BattleMode.PlayerDied()`;
- solta cubo/gemas;
- cria efeitos de morte/loot.

Defeitos relevantes:

- dano acumulado no mesmo tick é apagado em `Character.PreTick()` antes do snapshot dependendo da ordem; o README reconhece problema de stacking/exibição;
- não há pushback;
- dano de melee está incompleto;
- vários efeitos de dados CSV não são usados;
- `PoisonBarrel` é limitado a 1 HP e usa timer customizado frágil;
- source nulo em certos ataques prejudica atribuição de kill.

## Regeneração

Após 60 ticks sem dano, cura uma vez por segundo. O valor vem de `CharacterData.RegeneratePerSecond`, com fallback interno observado no código.

## Buffs, imunidade e veneno

- `Immunity`: reduz dano por percentual por N ticks.
- `Poison`: dano dividido em ticks de 1 segundo.
- `Buff`: duração e modificador; stacking somente para tipo 10.

`Buff.OnBuffEnd()` está vazio e várias propriedades não produzem comportamento concreto.

## Bots/IA

Bots procuram inimigo próximo e atacam/movem por lógica simples. O sistema também controla NPCs/summons.

Limitações confirmadas pela implementação:

- busca linear global;
- pouca/noção de line-of-sight;
- podem selecionar alvos inadequados;
- invisibilidade não é uma barreira confiável para aquisição de alvo;
- desvio de obstáculos gira o ângulo em loop, sem pathfinding;
- podem agir de forma incoerente perto de paredes ou mortos.

---

# 13. Projéteis e colisões

## `Projectile.cs`

Implementa:

- movimento por ângulo e velocidade;
- projétil direto e indireto;
- colisão com personagens;
- destruição de tiles;
- piercing;
- poison e freeze;
- chain bullet;
- áreas de efeito ao terminar;
- summon de personagem.

## Colisão

Para cada projétil, percorre todos os objetos e testa distância por soma dos raios. Ignora aliados pelo `Index / 16`.

### Falhas

- custo é O(projéteis × objetos) por tick;
- não usa swept collision: projétil rápido pode atravessar alvo entre ticks;
- chain bullet chama `GetClosestAlly()` sem verificar nulo antes de acessar posição;
- pushback e stun presentes no CSV não são implementados no impacto;
- `AlreadyDamagedObjectsGlobalIds` impede dano repetido, mas várias regras de `SameProjectileCanNotDamageMS`/dano constante são ignoradas;
- cálculo `GetModifiedDamage()` depende de `m_totalDelta` em escala pouco clara e é reconhecido no README como incorreto para Sniper;
- grande bloco `ExecuteChainBullet()` é código decompilado comentado, não funcional.

---

# 14. Efeitos de área e itens

## `AreaEffect.cs`

Tipos ativos:

- `Damage`: dano único em inimigos;
- `BulletExplosion`: projéteis radiais;
- `Dot`: dano periódico;
- `Hot`: efeito em aliados heróis.

Também pode destruir tiles dentro do raio.

Falhas:

- `Hot` chama `CauseDamage(..., EffectData.Damage)`; se o CSV usa dano positivo, isso machuca aliados, e cura só ocorre se o valor for negativo;
- `m_source` é acessado sem null check em comparações de time;
- longa seção inicial é pseudocódigo decompilado comentado;
- área da turret/efeitos persistentes não se liga ao ciclo de vida do summon;
- pushback de área não é implementado.

## `Item.cs`

Implementa pickups e nomes:

- Health, Speed, Damage;
- Point;
- Corpse;
- OrbSpawner;
- Mine;
- SupplyCrate;
- BoxOfMines;
- BattleRoyaleBuff;
- Money.

Na prática, `Character.ApplyItem()` trata principalmente:

- `BattleRoyaleBuff`: HP e dano + contagem;
- `Money`: +1 score;
- `Point`: gema/artefato e +1 score.

Muitos tipos são apenas codificados nominalmente, sem efeito completo.

---

# 15. Mapas e tiles

## `TileMapFactory.cs`

Lê `Assets/tilemaps.json` e cria mapa pelo nome `Location.AllowedMaps`.

## `TileMap.cs`

Interpreta códigos:

- `1`: spawn time 1;
- `2`: spawn time 2;
- `4`: loot box/barrel;
- `5`: poison barrel;
- `6..9`: safe.

Conversão: um tile corresponde a 300 unidades lógicas, com centro em `300 * tile + 150`.

## `Tile.cs`

Mantém dados e flag `Destructed`. `GetCheckSum()` retorna sempre zero.

### Incompletudes

- `TileMap.Tick()` é vazio;
- tiles destruídos não regeneram, mesmo quando `RespawnSeconds > 0`;
- checksum de tile não existe;
- `TileCodeToInstanceId()` retorna sempre -1;
- várias posições de objetivos são hard-coded como `(3150, 4950)` em vez de derivadas do centro do mapa. Isso explica objetivos descentralizados em mapas diferentes.

---

# 16. Regras por modo

## Variação 0 — Gem Grab / CoinRush

- cria `OrbSpawner` em `(3150, 4950)`;
- gera uma gema a cada 100 ticks (5 s);
- coleta incrementa item e score;
- morte zera score e derruba gemas;
- time com pelo menos 10 e vantagem inicia countdown de 17 s;
- perde a condição se ficar sem vantagem/abaixo da meta.

No timeout normal, o código encerra sem calcular o maior score; tende a empate.

## Variação 1 — Campaign

Reconhecida, mas sem regra própria. Termina apenas pelo limite geral. README/código avisam que é de dev build.

## Variação 2 — Heist / AttackDefend

- cria uma única safe conforme código do mapa;
- batalha acaba quando uma base morre;
- determina vencedor pelo `Index / 16` da base.

Limitações: modelagem de uma única safe pode não representar corretamente duas bases; índice hard-coded é frágil.

## Variação 3 — Bounty

- cria `Money` no centro hard-coded;
- kills adicionam estrelas/score;
- termina após `20 * 120 + 120 = 2520` ticks (~126 s);
- compara placar dos times e admite empate.

No snapshot, os valores específicos do modo escrevem constantes 100 em apenas 3 bits, o que merece revisão de protocolo.

## Variação 4 — Artifact

- spawna um único `Point` no tick 600 (30 s);
- jogador com artefato dá score ao time;
- time em vantagem inicia countdown de 30 s;
- morte reseta score e derruba o item.

Posição central também é hard-coded.

## Variação 5 — Brawl Ball / LaserBall

- cria a bola como `Character` `LaserBall` no centro.
- **Não há lógica de posse, chute, gol, placar ou vitória.**
- `CalculateIsGameOver()` não possui case 5; antes do timeout retorna false pelo `default`, e no timeout encerra com `m_winnerTeam = -1`.
- resultado prático: empate por tempo.

## Variação 6 — Showdown

- 10 participantes;
- spawns individuais usando `SpawnPointsTeam1`;
- caixas aleatórias em ~50% dos pontos;
- veneno fecha a partir do tick 500 e avança a cada 100 ticks;
- dano do veneno é 250 aproximadamente a cada 21 ticks;
- morte reduz `m_playersAlive`, define rank e envia resultado imediatamente ao humano morto;
- último vivo encerra a partida;
- cubos aumentam HP e dano.

Falhas:

- limites do veneno usam constantes `59`, pressupondo mapa 60×60;
- tokens usam `40 / rank` com divisão inteira;
- `SoloWins` não é incrementado;
- vencedor recebe resultado no encerramento geral; mortos já receberam individualmente;
- a partida pode terminar por limite enorme de 16000 ticks (~800 s), mas nesse caso a lógica não classifica todos de modo robusto.

---

# 17. Respawn

Em modos não-Showdown, `PlayerDied()`:

- zera `OwnObjectId`;
- agenda `DiedEntry`;
- Gem Grab/Artifact zeram score;
- após `GetRespawnSeconds()`, cria novo `Character` com imunidade de 60 ticks.

Tempos:

- Gem Grab e Heist: 3 s;
- Bounty: 1 s;
- padrão: 5 s.

Problemas:

- o dicionário `m_playersByObjectGlobalId` mantém os IDs antigos e adiciona os novos; entradas obsoletas acumulam;
- personagem novo recebe bot/nível, mas o estado de buffs/itens não é restaurado;
- não há escolha dinâmica de spawn seguro;
- imunidade funciona para dano, mas IA ainda pode mirar o jogador.

---

# 18. Snapshots e protocolo de batalha

## `StartLoadingMessage`

Codifica jogadores, índices, modo e localização. Campos de spectate não são usados na serialização.

## `VisionUpdateMessage`

Codifica:

- tick;
- último input tratado;
- “command count” fixo 1;
- bytes do `BitStream`.

`Viewers` não é codificado.

## Envio

`BattleMode.SendVisionUpdateToPlayers()` usa `Parallel.ForEach` para humanos e um `Task.Run` para espectadores.

Cada jogador recebe uma visão separada com seu `OwnObjectId`, time e input confirmado.

### Riscos

- 20 snapshots por segundo por jogador, reconstruindo o mundo completo;
- tasks podem acumular se rede/codificação atrasar;
- `UDPGameListener.SendMessage()` não faz backpressure;
- exceções gerais são capturadas no método, mas uma falha pode suprimir atualizações do tick;
- não há delta compression, relevância espacial ou MTU fragmentation handling;
- datagramas enviados podem exceder MTU e fragmentar.

---

# 19. Encerramento, recompensa e persistência

## Determinação de fim

Duração normal: `m_NORMAL_TICKS = 3600` (180 s). Showdown: `16000` (800 s).

Regras específicas podem terminar antes. Quando o tempo geral acaba, vários modos não calculam vencedor e permanecem em empate.

## `BattleEndMessage`

Enviado via TCP. Inclui:

- modo;
- resultado;
- tokens;
- troféus;
- jogadores;
- estatísticas/progresso parcialmente hard-coded.

## Recompensas 3v3

- empate: 10 tokens, 0 troféus;
- vitória: 20 tokens, troféus aleatórios efetivamente entre 6 e 8;
- derrota: 10 tokens, -2 troféus limitado pelo saldo.

## Showdown

- tokens: `40 / rank`;
- rank > 5: perde `rank - 5` troféus;
- rank ≤ 5: ganha `(5 - rank) * 2`.

## Persistência

A recompensa altera os objetos `ClientAvatar`, `ClientHome` e `Hero` em memória. `AccountCache` chama `Accounts.Save()` em todas as contas cacheadas a cada 30 segundos.

Riscos:

- crash antes do próximo save perde recompensa;
- não há transação por fim de partida;
- cache usa `Dictionary` comum entre threads;
- save em massa síncrono pode bloquear e falhar parcialmente;
- o final da batalha não chama save explicitamente;
- resultados/recompensas não têm idempotency key; fluxos duplicados poderiam premiar mais de uma vez se `GameOver()` for acionado em corrida.

---

# 20. Falhas de segurança e autoridade

## Críticas

1. **UDP hijacking:** sessão incremental, primeiro endpoint vence, nonce zero.
2. **DoS por datagrama:** `Task.Run` ilimitado por pacote.
3. **DoS por input:** sem limite de inputs/fila/rate.
4. **Concorrência:** estado mutável sem locks pode duplicar final/recompensa ou quebrar partida.
5. **Matchmaking destrutivo:** `Slots` recriado em cada pedido.

## Altas

1. Qualquer membro altera evento/status/configuração da sala; não há autorização de owner.
2. Capacidade de sala só existe no encoder, não como regra.
3. Inputs de ultimate não validam corretamente a carga no caminho ativo.
4. Ataques aceitam vetores arbitrários e não há validação forte de estado.
5. Sockets/salas/espectadores não têm coleta completa, causando vazamento.

## Médias

1. IDs previsíveis de batalha, sala e UDP.
2. Sem rate limit de criação/invite/chat/matchmaking.
3. Exceções são frequentemente ignoradas.
4. Estado de partida não é persistido.
5. Sem métricas, watchdog, tracing ou auditoria de resultado.

---

# 21. Problemas de concorrência detalhados

Coleções inseguras acessadas por múltiplas threads:

- `Matchmaking.Slots`;
- `MatchmakingSlot.RequestQueue/RemoveQueue/Queue`;
- `Teams.Entries`;
- `UDPGateway.Sockets`;
- `BattleMode.m_inputQueue`;
- dicionários/listas de jogadores/espectadores;
- `GameObjectManager` e suas filas;
- `AccountCache.CachedAccounts`;
- listas de conexões TCP.

Fontes concorrentes:

- thread TCP/async callbacks;
- thread UDP;
- `Task.Run` por UDP;
- thread de matchmaking;
- `Timer` de cada batalha;
- `Parallel.ForEach` de snapshots;
- timer de eventos;
- thread de save;
- threads de limpeza.

A arquitetura precisa de um princípio de ownership: idealmente cada batalha deve processar todas as mensagens em um único loop/fila, sem mutação externa.

---

# 22. Inventário completo dos arquivos responsáveis

## A. Núcleo direto da batalha

| Arquivo | Responsabilidade |
|---|---|
| `Logic/Battle/BattleMode.cs` | estado, tick, inputs, spawn, respawn, regras, fim, snapshots |
| `Logic/Battle/Structures/BattlePlayer.cs` | jogador, time, score, ulti, estatísticas, vínculo Home/Avatar |
| `Logic/Battle/Structures/PlayerKillEntry.cs` | evento de kill/bounty no snapshot |
| `Logic/Battle/Input/ClientInput.cs` | protocolo de comandos do jogador |
| `Logic/Battle/Objects/GameObject.cs` | base de todos os objetos |
| `Logic/Battle/Objects/GameObjectManager.cs` | ciclo de vida e encoding do mundo |
| `Logic/Battle/Objects/Character.cs` | heróis, NPCs, bots, movimento, dano, skills |
| `Logic/Battle/Objects/Projectile.cs` | tiros, colisões, efeitos e summons |
| `Logic/Battle/Objects/AreaEffect.cs` | dano/DoT/HoT/explosão em área |
| `Logic/Battle/Objects/Item.cs` | pickups, gemas, cubos, money/mines |
| `Logic/Battle/Component/Skill.cs` | carga, recarga, duração e cadência |
| `Logic/Battle/Component/Buff.cs` | status buffs |
| `Logic/Battle/Component/Immunity.cs` | redução temporária de dano |
| `Logic/Battle/Component/Poison.cs` | dano periódico |
| `Logic/Battle/Level/Rect.cs` | limites jogáveis |
| `Logic/Battle/Level/Tile.cs` | estado individual do tile |
| `Logic/Battle/Level/TileMap.cs` | mapa, spawns e objetivos |
| `Logic/Battle/Level/Factory/TileMapFactory.cs` | carregamento de tilemap |
| `Logic/Time/GameTime.cs` | contador de ticks |

## B. Orquestração server-side

| Arquivo | Responsabilidade |
|---|---|
| `Server/Logic/Game/Battles.cs` | registro e remoção de batalhas |
| `Server/Logic/Game/Matchmaking.cs` | filas, times, bots, criação da partida |
| `Server/Logic/Game/Events.cs` | rotação slot→localização/modo |
| `Server/Logic/Game/Teams.cs` | registro das GameRooms e partida em grupo |
| `Server/Resources.cs` | inicialização de lógica/rede |
| `Server/Message/MessageManager.cs` | handlers de matchmaking, sala, spectate, reconnect |
| `Server/Networking/Connection.cs` | estado TCP/UDP/matchmaking por conexão |
| `Server/Networking/Session/Session.cs` | vínculo sessão-home-conexão |
| `Server/Networking/Session/Sessions.cs` | presença, desconexão e estado de sala |

## C. Rede da batalha

| Arquivo | Responsabilidade |
|---|---|
| `Server/Networking/UDP/UDPGateway.cs` | recepção/envio UDP e tabela de sockets |
| `Server/Networking/UDP/UDPSocket.cs` | frame UDP e despacho de inputs |
| `Server/Networking/UDP/Game/UDPGameListener.cs` | saída UDP e fim via TCP |
| `Server/Networking/TCPGateway.cs` | conexão e recepção TCP |
| `Server/Networking/Messaging.cs` | framing/crypto das mensagens TCP |
| `Server/Message/Processor.cs` | processamento das mensagens TCP |
| `Logic/Listener/LogicGameListener.cs` | abstração de envio battle/home |
| `Server/Logic/HomeGameListener.cs` | listener TCP do home |

## D. Mensagens de batalha/matchmaking/UDP

- `Message/Battle/BattleEndMessage.cs`
- `Message/Battle/ClientInputMessage.cs`
- `Message/Battle/StartLoadingMessage.cs`
- `Message/Battle/StartSpectateMessage.cs`
- `Message/Battle/VisionUpdateMessage.cs`
- `Message/Home/MatchmakeRequestMessage.cs`
- `Message/Home/CancelMatchmakingMessage.cs`
- `Message/Home/MatchMakingCancelledMessage.cs`
- `Message/Home/MatchMakingStatusMessage.cs`
- `Message/Home/StopSpectateMessage.cs`
- `Message/Home/GoHomeMessage.cs`
- `Message/Udp/ClientInfoMessage.cs`
- `Message/Udp/UdpConnectionInfoMessage.cs`
- `Message/MessageFactory.cs`

## E. Modelo e mensagens das GameRooms

- `Team/TeamEntry.cs`
- `Team/TeamMember.cs`
- `Team/TeamInviteEntry.cs`
- `Team/TeamJoinRequest.cs`
- `Team/Stream/TeamStreamEntry.cs`
- `Team/Stream/ChatStreamEntry.cs`
- `Team/Stream/TeamCreatedStreamEntry.cs`
- `Message/Team/TeamCreateMessage.cs`
- `Message/Team/TeamLeaveMessage.cs`
- `Message/Team/TeamLeftMessage.cs`
- `Message/Team/TeamMessage.cs`
- `Message/Team/TeamInviteMessage.cs`
- `Message/Team/TeamInvitationMessage.cs`
- `Message/Team/TeamInvitationResponseMessage.cs`
- `Message/Team/TeamChangeMemberSettingsMessage.cs`
- `Message/Team/TeamSetMemberReadyMessage.cs`
- `Message/Team/TeamSetEventMessage.cs`
- `Message/Team/TeamSetLocationMessage.cs`
- `Message/Team/TeamMemberStatusMessage.cs`
- `Message/Team/TeamGameStartingMessage.cs`
- `Message/Team/Stream/TeamChatMessage.cs`
- `Message/Team/Stream/TeamPremadeChatMessage.cs`
- `Message/Team/Stream/QuickChatStreamEntry.cs`
- `Message/Team/Stream/TeamStreamMessage.cs`

## F. Dados que determinam a lógica

Classes:

- `Data/CharacterData.cs`
- `Data/SkillData.cs`
- `Data/ProjectileData.cs`
- `Data/AreaEffectData.cs`
- `Data/ItemData.cs`
- `Data/LocationData.cs`
- `Data/TileData.cs`
- `Data/DataTables.cs`
- `Data/Helper/DataTable.cs`
- `Data/Reader/*`
- `Util/GameModeUtil.cs`
- `Util/GamePlayUtil.cs`

Assets:

- `Assets/csv_logic/characters.csv`
- `Assets/csv_logic/skills.csv`
- `Assets/csv_logic/projectiles.csv`
- `Assets/csv_logic/area_effects.csv`
- `Assets/csv_logic/items.csv`
- `Assets/csv_logic/locations.csv`
- `Assets/csv_logic/tiles.csv`
- `Assets/tilemaps.json`
- `Server/gameplay.json`
- `Server/config.json`

## G. Conta e persistência afetadas pela batalha

- `Avatar/ClientAvatar.cs` — BattleId, UDP, índices e recompensas;
- `Home/ClientHome.cs` — personagem e recompensas temporárias;
- `Home/Structures/Hero.cs` — troféus;
- `Database/Models/Account.cs` — agregado salvo;
- `Database/Cache/AccountCache.cs` — autosave a cada 30 s;
- `Database/Accounts.cs` — persistência MySQL.

---

# 23. Ordem recomendada de correção

## Fase 0 — tornar o commit executável e observável

1. build e testes automatizados em CI;
2. logs estruturados por `battleId`, `accountId`, `udpSessionId`;
3. testes de protocolo/encoding com golden packets;
4. métricas de tick, fila, pacote, batalha e memória.

## Fase 1 — bloqueadores

1. remover a recriação de `Matchmaking.Slots` em `RequestMatchmake()`;
2. inicializar eventos sincronamente antes do matchmaking;
3. usar uma fila concorrente por slot e estado explícito do jogador;
4. autenticar UDP com token aleatório forte/nonce ligado à sessão TCP;
5. remover sockets no fim/desconexão;
6. loop single-thread por batalha, sem `Timer` reentrante;
7. limitar pacotes, inputs, filas e tasks.

## Fase 2 — GameRoom correta

1. capacidade server-side 3;
2. owner/leader authorization;
3. estados `Open`, `Queueing`, `InBattle`, `Closed`;
4. impedir múltiplas salas/filas;
5. convite com expiração e deduplicação;
6. transferir owner na saída;
7. matchmaking atômico da party inteira;
8. limpar sala e ready após partida/cancelamento.

## Fase 3 — integridade da batalha

1. validar ultimate, skill, range e rate;
2. consertar buffs de velocidade;
3. implementar melee, charge, pushback e stun;
4. corrigir winner no timeout;
5. limpar mapeamento de objetos mortos;
6. tornar objetivos dependentes do mapa, não de `(3150,4950)`;
7. implementar Brawl Ball ou removê-lo da disponibilidade;
8. corrigir power level/skin.

## Fase 4 — desempenho

1. spatial hash/quadtree para colisão e IA;
2. snapshots delta/relevância espacial;
3. buffers reutilizáveis;
4. evitar `Parallel.ForEach` e `Task.Run` por pacote/tick;
5. backpressure e orçamento fixo por batalha.

## Fase 5 — recompensa confiável

1. resultado idempotente por battle ID;
2. transação de recompensa;
3. persistência imediata ou fila durável;
4. auditoria server-side;
5. proteção contra finalização duplicada.

---

# 24. Conclusão

O servidor possui um esqueleto completo e reconhecível de batalha online autoritativa, mas está em estado de protótipo. O caminho funcional é bem definido — evento → matchmaking/team → `BattleMode` → UDP → tick → snapshot → recompensa — porém há três fragilidades sistêmicas:

1. **estado global concorrente sem ownership/sincronização**;
2. **protocolo UDP previsível e sem autenticação**;
3. **mecânicas parcialmente implementadas e regras de fim incompletas**.

A GameRoom não é uma entidade persistente: é um `TeamEntry` temporário em memória, com poucos controles de autorização e integridade. A batalha também não deve ser considerada segura para produção enquanto matchmaking, UDP e loop de tick não forem refeitos.

## Nota sobre validação

A análise foi feita diretamente sobre todos os arquivos relacionados e dependências listadas no commit acima. Tentei executar `dotnet build`, mas o ambiente de análise não possui o SDK `dotnet` instalado (`dotnet: command not found`). Portanto, a revisão de comportamento e defeitos é estática; não alego que o projeto compilou ou passou em testes neste ambiente.
