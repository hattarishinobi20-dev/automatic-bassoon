# RoyaleBrawl v1
Private brawl stars server with PvP Battles (v1.1714)

![Screenshot](https://github.com/Super-Brawl-team/RoyaleBrawl-v1/blob/main/screenshots/gameplay.png)

## [DOWNLOAD CLIENT](https://www.mediafire.com/file/yjp6addb6w9op7b/RoyaleBrawlV1.ipa/file)

### Setup
##### Compiling
- Method 1: Open .sln file in Visual Studio and run project `Supercell.Laser.Server`
- Method 2: Compile `Supercell.Laser.Server.csproj` using `dotnet` & run it using `dotnet Supercell.Laser.Server.dll`
##### Database
You need to setup mysql server and import `database.sql` file from this repository.
##### Configuration
- Set your ip in `config.json` -> `udp_host`
- Set your mysql database name, password, and username in `config.json`
##### Client
- Download ipa here: [link](https://www.mediafire.com/file/yjp6addb6w9op7b/RoyaleBrawlV1.ipa/file)
- Open this file: `Payload/Brawl Stars.app/Brawl Stars` and open in an hex editor to put your ip address instead of "192.168.1.184"
- Recompress ipa and play enjoy playing this server.
           
### Requirements
- dotnet 6.0
- mysql (on windows I prefer *XAMPP* with *phpmyadmin*)

### Features:
- PvP Battles
- Online game rooms
- Alliances
- Leaderboards
- Events refresh

### TODO ON MENU
- Decent box logic
- A bit of rewrite

### TODO ON BATTLES
- Brawl Ball, gems and bounty stars are not centered
- Fix battle end crashing for some reason
- Fix Jessie's chain always aiming to the left
- Fix Minigunner's turret's area effect not disapearing when the turret is killed
- FIx Sniper's attack always inflicting the maximum damages, and his ulti type teleporting him to coordinates 0,0
- Fix Primo's attack doing nothing
- Fix charges not beeing implemented
- Fix damages not stacking when they are inflicted on the same tick, and beeing displayed to other players
- Fix invibility not having any effect on bots who will still attack you
- Fix bots beeing weird (attacking dead players?? and trying to attack players through walls lol)
- Fix pushback not being implemented
- Fix slow down effect not doing anything
- Implement the unused mechanics
- Fixing projectile spread such as colt and minigunner not beeing spread
- And in general just use lib code instead of the weird thing RoyaleBrawl did
